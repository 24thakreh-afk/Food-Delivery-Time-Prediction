import React, { useState, useEffect, useRef } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { 
  MapPin, 
  Clock, 
  CheckCircle2, 
  Play, 
  Pause, 
  RotateCcw, 
  ArrowLeft, 
  AlertTriangle,
  ChefHat,
  Bike,
  Home as HomeIcon,
  ShoppingBag,
  Zap,
  Info
} from 'lucide-react';
import { useOrder } from '../context/OrderContext';
import { MapContainer, TileLayer, Marker, Polyline, Popup, useMap } from 'react-leaflet';
import L from 'leaflet';

// Custom modern SVG-based DivIcons for Leaflet
const createCustomIcon = (bgColor, iconText) => {
  return L.divIcon({
    className: 'custom-map-marker',
    html: `
      <div style="
        background-color: ${bgColor};
        color: white;
        width: 38px;
        height: 38px;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 18px;
        box-shadow: 0 4px 10px rgba(0,0,0,0.3);
        border: 3px solid white;
      ">
        ${iconText}
      </div>
    `,
    iconSize: [38, 38],
    iconAnchor: [19, 19]
  });
};

const restaurantIcon = createCustomIcon('#10b981', '🍕');
const customerIcon = createCustomIcon('#f97316', '🏠');
const courierIcon = createCustomIcon('#0284c7', '🛵');

// Center map component
function ChangeView({ center }) {
  const map = useMap();
  map.setView(center, 13);
  return null;
}

export default function Tracking() {
  const navigate = useNavigate();
  const { selectedRestaurant, cartItems, features, lastPrediction } = useOrder();

  // Simulated Coordinates (e.g. San Francisco or Metropolitan area coordinates)
  const restaurantCoords = [37.7749, -122.4194]; // City Center
  const destinationCoords = [
    37.7749 + (features.distance_km * 0.007),
    -122.4194 + (features.distance_km * 0.006)
  ];

  // Route Waypoints for the simulation
  const routePoints = [
    restaurantCoords,
    [restaurantCoords[0] + (destinationCoords[0] - restaurantCoords[0]) * 0.25, restaurantCoords[1] + (destinationCoords[1] - restaurantCoords[1]) * 0.1],
    [restaurantCoords[0] + (destinationCoords[0] - restaurantCoords[0]) * 0.5, restaurantCoords[1] + (destinationCoords[1] - restaurantCoords[1]) * 0.6],
    [restaurantCoords[0] + (destinationCoords[0] - restaurantCoords[0]) * 0.75, restaurantCoords[1] + (destinationCoords[1] - restaurantCoords[1]) * 0.85],
    destinationCoords
  ];

  // Simulation State
  const predictedMinutes = lastPrediction ? lastPrediction.best_model.predicted_time_min : 32.5;
  const etaText = lastPrediction ? lastPrediction.estimated_eta : '08:45 PM';

  const [progress, setProgress] = useState(15); // 0 to 100%
  const [isPlaying, setIsPlaying] = useState(true);
  const [speed, setSpeed] = useState(2); // 1x, 2x, 5x
  const timerRef = useRef(null);

  useEffect(() => {
    if (isPlaying && progress < 100) {
      timerRef.current = setInterval(() => {
        setProgress(prev => {
          if (prev >= 100) {
            setIsPlaying(false);
            return 100;
          }
          return Math.min(100, prev + 1 * speed);
        });
      }, 500);
    }
    return () => clearInterval(timerRef.current);
  }, [isPlaying, progress, speed]);

  // Determine current stage
  let currentStage = 'Order Preparation';
  let stageIndex = 1;
  if (progress >= 35 && progress < 90) {
    currentStage = 'Out for Delivery';
    stageIndex = 2;
  } else if (progress >= 90) {
    currentStage = 'Delivered!';
    stageIndex = 3;
  }

  // Calculate Courier Position along polyline
  const interpolatePosition = (t) => {
    const fraction = t / 100;
    const lat = restaurantCoords[0] + (destinationCoords[0] - restaurantCoords[0]) * fraction;
    const lng = restaurantCoords[1] + (destinationCoords[1] - restaurantCoords[1]) * fraction;
    return [lat, lng];
  };

  const courierPos = interpolatePosition(progress);

  return (
    <div className="fade-in">
      {/* Simulation Notice Banner */}
      <div style={{
        backgroundColor: '#fffbeb',
        border: '1px solid #fde68a',
        color: '#92400e',
        padding: '0.85rem 1.25rem',
        borderRadius: '12px',
        marginBottom: '1.5rem',
        display: 'flex',
        alignItems: 'center',
        gap: '0.75rem',
        fontSize: '0.875rem'
      }}>
        <AlertTriangle size={20} color="#d97706" style={{ flexShrink: 0 }} />
        <div>
          <strong>Simulation Mode:</strong> This page simulates realistic food preparation and delivery transit progress based on the <strong>{predictedMinutes} minute ETA</strong> predicted by our machine learning models. No live commercial tracking is connected.
        </div>
      </div>

      {/* Top Header */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1.75rem', flexWrap: 'wrap', gap: '1rem' }}>
        <div>
          <div className="badge badge-orange" style={{ marginBottom: '0.35rem' }}>
            <MapPin size={13} />
            <span>Page 3: Delivery Tracking Simulation</span>
          </div>
          <h1 style={{ fontSize: '2rem', fontWeight: '800', color: '#0f172a' }}>
            Live Delivery Route & Progress Simulation
          </h1>
        </div>

        <div style={{ display: 'flex', gap: '0.75rem' }}>
          <button onClick={() => navigate('/predict')} className="btn btn-secondary">
            <ArrowLeft size={16} />
            <span>Change Order Features</span>
          </button>
          <Link to="/compare" className="btn btn-primary">
            <span>Compare 4 Models</span>
          </Link>
        </div>
      </div>

      {/* Main Grid: Map & Status Cards */}
      <div style={{
        display: 'grid',
        gridTemplateColumns: 'repeat(auto-fit, minmax(320px, 1fr))',
        gap: '1.75rem',
        alignItems: 'start'
      }}>
        {/* Left: OpenStreetMap Leaflet Container */}
        <div className="card" style={{ padding: '0', overflow: 'hidden', height: '480px', position: 'relative' }}>
          <MapContainer
            center={restaurantCoords}
            zoom={13}
            scrollWheelZoom={false}
            style={{ width: '100%', height: '100%' }}
          >
            <ChangeView center={courierPos} />
            <TileLayer
              attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
              url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
            />
            {/* Restaurant Pickup Point */}
            <Marker position={restaurantCoords} icon={restaurantIcon}>
              <Popup>
                <strong>{selectedRestaurant.name}</strong><br />
                Pickup Location • Prep Time: {features.preparation_time_min} mins
              </Popup>
            </Marker>

            {/* Customer Destination */}
            <Marker position={destinationCoords} icon={customerIcon}>
              <Popup>
                <strong>Delivery Destination</strong><br />
                Distance: {features.distance_km} km from restaurant
              </Popup>
            </Marker>

            {/* Courier Position */}
            <Marker position={courierPos} icon={courierIcon}>
              <Popup>
                <strong>Courier ({features.vehicle_type})</strong><br />
                Experience: {features.courier_experience_yrs} yrs • Progress: {progress}%
              </Popup>
            </Marker>

            {/* Simulated Route Polyline */}
            <Polyline positions={routePoints} color="#10b981" weight={5} dashArray="8, 8" />
          </MapContainer>

          {/* Floating Map Legend Overlay */}
          <div style={{
            position: 'absolute',
            bottom: '15px',
            left: '15px',
            backgroundColor: 'rgba(255, 255, 255, 0.95)',
            backdropFilter: 'blur(4px)',
            padding: '0.65rem 1rem',
            borderRadius: '10px',
            boxShadow: '0 4px 10px rgba(0,0,0,0.15)',
            zIndex: 1000,
            fontSize: '0.78rem',
            display: 'flex',
            gap: '1rem',
            alignItems: 'center'
          }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.35rem' }}>
              <span>🍕</span> <strong>Restaurant</strong>
            </div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.35rem' }}>
              <span>🛵</span> <strong>Courier ({features.vehicle_type})</strong>
            </div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.35rem' }}>
              <span>🏠</span> <strong>Destination</strong>
            </div>
          </div>
        </div>

        {/* Right: Progress Tracker & Simulation Controller */}
        <div>
          {/* Status Tracker Card */}
          <div className="card" style={{ marginBottom: '1.5rem' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '1.25rem' }}>
              <div>
                <span className="badge badge-green" style={{ marginBottom: '0.25rem' }}>
                  Stage {stageIndex} of 3
                </span>
                <h2 style={{ fontSize: '1.5rem', fontWeight: '800', color: '#0f172a' }}>
                  {currentStage}
                </h2>
                <div style={{ fontSize: '0.85rem', color: '#64748b' }}>
                  Expected Arrival: <strong style={{ color: '#0f172a' }}>{etaText}</strong> (in ~{Math.max(1, Math.round(predictedMinutes * (1 - progress/100)))} mins)
                </div>
              </div>

              <div style={{ textAlign: 'right' }}>
                <div style={{ fontSize: '1.75rem', fontWeight: '800', color: '#10b981' }}>
                  {progress}%
                </div>
                <div style={{ fontSize: '0.75rem', color: '#94a3b8' }}>Complete</div>
              </div>
            </div>

            {/* Continuous Progress Bar */}
            <div style={{
              width: '100%',
              height: '8px',
              backgroundColor: '#e2e8f0',
              borderRadius: '9999px',
              overflow: 'hidden',
              marginBottom: '1.75rem'
            }}>
              <div style={{
                width: `${progress}%`,
                height: '100%',
                backgroundColor: progress >= 100 ? '#10b981' : '#0284c7',
                transition: 'width 0.3s ease'
              }} />
            </div>

            {/* Three Clearly Labelled Stages Timeline */}
            <div style={{ display: 'flex', flexDirection: 'column', gap: '1.25rem' }}>
              {/* Stage 1: Order Preparation */}
              <div style={{ display: 'flex', alignItems: 'flex-start', gap: '0.85rem' }}>
                <div style={{
                  width: '32px',
                  height: '32px',
                  borderRadius: '50%',
                  backgroundColor: progress >= 10 ? '#ecfdf5' : '#f1f5f9',
                  color: progress >= 10 ? '#10b981' : '#94a3b8',
                  border: `2px solid ${progress >= 10 ? '#10b981' : '#cbd5e1'}`,
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  fontWeight: '700',
                  fontSize: '0.85rem',
                  flexShrink: 0
                }}>
                  {progress >= 35 ? <CheckCircle2 size={18} /> : <ChefHat size={16} />}
                </div>
                <div>
                  <div style={{ fontSize: '0.95rem', fontWeight: '700', color: '#0f172a' }}>
                    1. Kitchen Preparation ({features.preparation_time_min} mins)
                  </div>
                  <div style={{ fontSize: '0.8rem', color: '#64748b' }}>
                    {selectedRestaurant.name} is preparing your fresh order.
                  </div>
                </div>
              </div>

              {/* Stage 2: Out for Delivery */}
              <div style={{ display: 'flex', alignItems: 'flex-start', gap: '0.85rem' }}>
                <div style={{
                  width: '32px',
                  height: '32px',
                  borderRadius: '50%',
                  backgroundColor: progress >= 35 ? '#eff6ff' : '#f1f5f9',
                  color: progress >= 35 ? '#0284c7' : '#94a3b8',
                  border: `2px solid ${progress >= 35 ? '#0284c7' : '#cbd5e1'}`,
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  fontWeight: '700',
                  fontSize: '0.85rem',
                  flexShrink: 0
                }}>
                  {progress >= 90 ? <CheckCircle2 size={18} /> : <Bike size={16} />}
                </div>
                <div>
                  <div style={{ fontSize: '0.95rem', fontWeight: '700', color: '#0f172a' }}>
                    2. Out for Delivery ({features.distance_km} km route)
                  </div>
                  <div style={{ fontSize: '0.8rem', color: '#64748b' }}>
                    Courier on {features.vehicle_type} navigating {features.traffic_level.toLowerCase()} traffic under {features.weather.toLowerCase()} skies.
                  </div>
                </div>
              </div>

              {/* Stage 3: Delivered */}
              <div style={{ display: 'flex', alignItems: 'flex-start', gap: '0.85rem' }}>
                <div style={{
                  width: '32px',
                  height: '32px',
                  borderRadius: '50%',
                  backgroundColor: progress >= 100 ? '#ecfdf5' : '#f1f5f9',
                  color: progress >= 100 ? '#10b981' : '#94a3b8',
                  border: `2px solid ${progress >= 100 ? '#10b981' : '#cbd5e1'}`,
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  fontWeight: '700',
                  fontSize: '0.85rem',
                  flexShrink: 0
                }}>
                  <HomeIcon size={16} />
                </div>
                <div>
                  <div style={{ fontSize: '0.95rem', fontWeight: '700', color: '#0f172a' }}>
                    3. Delivered to Destination
                  </div>
                  <div style={{ fontSize: '0.8rem', color: '#64748b' }}>
                    Handover completed within predicted {predictedMinutes} minute window.
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Simulation Controller Card */}
          <div className="card">
            <h3 style={{ fontSize: '1rem', fontWeight: '700', marginBottom: '0.75rem', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
              <Play size={16} color="#10b981" />
              <span>Simulation Controls</span>
            </h3>

            <div style={{ display: 'flex', gap: '0.75rem', alignItems: 'center', flexWrap: 'wrap' }}>
              <button
                onClick={() => setIsPlaying(!isPlaying)}
                className={`btn ${isPlaying ? 'btn-secondary' : 'btn-primary'}`}
                style={{ padding: '0.65rem 1rem' }}
              >
                {isPlaying ? <><Pause size={16} /> Pause</> : <><Play size={16} /> Resume</>}
              </button>

              <button
                onClick={() => { setProgress(0); setIsPlaying(true); }}
                className="btn btn-secondary"
                style={{ padding: '0.65rem 1rem' }}
              >
                <RotateCcw size={16} /> Restart
              </button>

              <div style={{ display: 'flex', gap: '0.25rem', marginLeft: 'auto' }}>
                {[1, 2, 5].map(spd => (
                  <button
                    key={spd}
                    onClick={() => setSpeed(spd)}
                    style={{
                      padding: '0.4rem 0.65rem',
                      borderRadius: '6px',
                      border: '1px solid var(--border-color)',
                      backgroundColor: speed === spd ? '#10b981' : 'white',
                      color: speed === spd ? 'white' : '#475569',
                      fontWeight: '700',
                      fontSize: '0.75rem',
                      cursor: 'pointer'
                    }}
                  >
                    {spd}x
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
