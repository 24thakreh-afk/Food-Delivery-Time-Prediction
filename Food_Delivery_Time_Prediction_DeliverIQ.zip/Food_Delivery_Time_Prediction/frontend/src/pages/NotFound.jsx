import React from 'react';
import { Link } from 'react-router-dom';
import { AlertCircle, Home, Zap } from 'lucide-react';

export default function NotFound() {
  return (
    <div className="card fade-in" style={{ textAlign: 'center', padding: '5rem 2rem', maxWidth: '500px', margin: '4rem auto' }}>
      <div style={{
        width: '64px',
        height: '64px',
        borderRadius: '50%',
        backgroundColor: '#fef2f2',
        color: '#ef4444',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        margin: '0 auto 1.5rem auto'
      }}>
        <AlertCircle size={32} />
      </div>
      <h1 style={{ fontSize: '2rem', fontWeight: '800', color: '#0f172a', marginBottom: '0.5rem' }}>
        404 — Page Not Found
      </h1>
      <p style={{ color: '#64748b', fontSize: '0.95rem', marginBottom: '2rem', lineHeight: '1.6' }}>
        The page you are looking for does not exist or has been moved. Use the navigation links to continue exploring DeliverIQ.
      </p>
      <div style={{ display: 'flex', gap: '0.75rem', justifyContent: 'center' }}>
        <Link to="/" className="btn btn-secondary">
          <Home size={16} />
          <span>Return to Home</span>
        </Link>
        <Link to="/predict" className="btn btn-primary">
          <Zap size={16} />
          <span>Predict Time</span>
        </Link>
      </div>
    </div>
  );
}
