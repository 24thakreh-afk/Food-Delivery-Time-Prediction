import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { 
  Zap, 
  Clock, 
  MapPin, 
  Navigation, 
  CloudSun, 
  Car, 
  Plus, 
  Minus, 
  Check, 
  AlertCircle, 
  ArrowRight, 
  RotateCcw,
  Sparkles,
  ShoppingBag,
  Award
} from 'lucide-react';
import { useOrder, SAMPLE_RESTAURANTS } from '../context/OrderContext';

export default function Prediction() {
  const navigate = useNavigate();
  const { 
    selectedRestaurant, 
    setSelectedRestaurant, 
    cartItems, 
    addToCart, 
    removeFromCart, 
    features, 
    updateFeature, 
    lastPrediction, 
    setLastPrediction, 
    isLoading, 
    setIsLoading 
  } = useOrder();

  const [errorMessage, setErrorMessage] = useState(null);
  const [successAnimation, setSuccessAnimation] = useState(false);

  const calculateTotal = () => {
    return cartItems.reduce((acc, item) => acc + item.price * item.qty, 0).toFixed(2);
  };

  const handlePredict = async (e) => {
    e.preventDefault();
    setErrorMessage(null);
    setIsLoading(true);

    try {
      const itemsSummary = cartItems.map(i => `${i.qty}x ${i.name}`).join(', ') || 'Custom Food Order';

      const payload = {
        distance_km: Number(features.distance_km),
        weather: features.weather,
        traffic_level: features.traffic_level,
        time_of_day: features.time_of_day,
        vehicle_type: features.vehicle_type,
        preparation_time_min: Number(features.preparation_time_min),
        courier_experience_yrs: Number(features.courier_experience_yrs),
        restaurant_name: selectedRestaurant.name,
        items_summary: itemsSummary,
        order_time: new Date().toISOString()
      };

      const res = await fetch('/api/predict', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });

      if (!res.ok) {
        const errorData = await res.json();
        throw new Error(errorData.error || 'Prediction request failed.');
      }

      const data = await res.json();
      setLastPrediction(data);
      setSuccessAnimation(true);
      setTimeout(() => setSuccessAnimation(false), 2000);

    } catch (err) {
      setErrorMessage(err.message || 'Could not connect to Flask prediction API.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="fade-in">
      {/* Header */}
      <div style={{ marginBottom: '2rem' }}>
        <div className="badge badge-green" style={{ marginBottom: '0.4rem' }}>
          <Zap size={13} />
          <span>Page 2: Order Simulation & Prediction</span>
        </div>
        <h1 style={{ fontSize: '2rem', fontWeight: '800', color: '#0f172a' }}>
          Configure Order & Predict Delivery Time
        </h1>
        <p style={{ color: '#64748b', fontSize: '0.95rem' }}>
          Configure your food order and live delivery conditions to query all 4 trained regression models via Flask.
        </p>
      </div>

      {errorMessage && (
        <div style={{
          backgroundColor: '#fef2f2',
          border: '1px solid #fecaca',
          color: '#b91c1c',
          borderRadius: '12px',
          padding: '1rem',
          marginBottom: '1.5rem',
          display: 'flex',
          alignItems: 'center',
          gap: '0.75rem'
        }}>
          <AlertCircle size={20} />
          <div>
            <strong>Prediction Failed:</strong> {errorMessage}
          </div>
        </div>
      )}

      <div style={{
        display: 'grid',
        gridTemplateColumns: 'repeat(auto-fit, minmax(320px, 1fr))',
        gap: '2rem',
        alignItems: 'start'
      }}>
        {/* Left Column: Restaurant & Cart Simulation */}
        <div>
          {/* Restaurant Selector */}
          <div className="card" style={{ marginBottom: '1.5rem' }}>
            <h2 className="card-title">
              <ShoppingBag size={18} color="#10b981" />
              <span>1. Choose Restaurant</span>
            </h2>
            <p className="card-subtitle">
              Select a partner kitchen to populate realistic prep time and distance estimates.
            </p>

            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: '0.75rem', marginBottom: '1rem' }}>
              {SAMPLE_RESTAURANTS.map((rest) => {
                const isSelected = selectedRestaurant.id === rest.id;
                return (
                  <div
                    key={rest.id}
                    onClick={() => {
                      setSelectedRestaurant(rest);
                      updateFeature('preparation_time_min', rest.prepTime);
                      updateFeature('distance_km', rest.distanceKm);
                    }}
                    style={{
                      border: `2px solid ${isSelected ? '#10b981' : '#e2e8f0'}`,
                      backgroundColor: isSelected ? '#ecfdf5' : 'white',
                      borderRadius: '10px',
                      padding: '0.75rem',
                      cursor: 'pointer',
                      transition: 'all 0.15s ease'
                    }}
                  >
                    <div style={{ fontSize: '0.85rem', fontWeight: '700', color: '#0f172a', marginBottom: '0.2rem' }}>
                      {rest.name}
                    </div>
                    <div style={{ fontSize: '0.75rem', color: '#64748b' }}>
                      {rest.prepTime} min prep • {rest.distanceKm} km
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Menu Items */}
            <div style={{ marginTop: '1rem' }}>
              <div style={{ fontSize: '0.85rem', fontWeight: '700', color: '#334155', marginBottom: '0.5rem' }}>
                {selectedRestaurant.name} Menu Items:
              </div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
                {selectedRestaurant.menu.map((item) => (
                  <div
                    key={item.id}
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'space-between',
                      padding: '0.65rem 0.85rem',
                      borderRadius: '8px',
                      backgroundColor: '#f8fafc',
                      border: '1px solid #f1f5f9'
                    }}
                  >
                    <div>
                      <div style={{ fontSize: '0.875rem', fontWeight: '600', color: '#0f172a' }}>{item.name}</div>
                      <div style={{ fontSize: '0.75rem', color: '#64748b' }}>${item.price.toFixed(2)}</div>
                    </div>
                    <button
                      type="button"
                      onClick={() => addToCart(item)}
                      className="btn btn-secondary"
                      style={{ padding: '0.35rem 0.65rem', fontSize: '0.78rem' }}
                    >
                      <Plus size={14} /> Add
                    </button>
                  </div>
                ))}
              </div>
            </div>

            {/* Order Summary */}
            <div style={{
              marginTop: '1.25rem',
              paddingTop: '1rem',
              borderTop: '1px dashed var(--border-color)',
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center'
            }}>
              <div>
                <span style={{ fontSize: '0.85rem', color: '#64748b' }}>Cart Items ({cartItems.reduce((a,b)=>a+b.qty,0)}): </span>
                <span style={{ fontSize: '0.9rem', fontWeight: '700', color: '#0f172a' }}>${calculateTotal()}</span>
              </div>
              <div style={{ display: 'flex', gap: '0.25rem' }}>
                {cartItems.map(item => (
                  <span key={item.id} style={{ fontSize: '0.72rem', backgroundColor: '#e2e8f0', padding: '0.15rem 0.45rem', borderRadius: '4px' }}>
                    {item.qty}x {item.name.split(' ')[0]}
                  </span>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Right Column: Exact ML Feature Inputs Form */}
        <div>
          <form onSubmit={handlePredict} className="card" style={{ boxShadow: 'var(--shadow-md)' }}>
            <h2 className="card-title">
              <Sparkles size={18} color="#10b981" />
              <span>2. Dataset Input Features</span>
            </h2>
            <p className="card-subtitle">
              These 7 inputs match the exact columns of <code style={{ color: '#0f172a' }}>Food_delivery_Times.csv</code>.
            </p>

            {/* Distance Slider & Input */}
            <div className="form-group">
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '0.4rem' }}>
                <label className="form-label">Delivery Distance (Distance_km)</label>
                <span style={{ fontWeight: '700', color: '#10b981', fontSize: '0.9rem' }}>
                  {features.distance_km} km
                </span>
              </div>
              <input
                type="range"
                min="0.5"
                max="20"
                step="0.1"
                value={features.distance_km}
                onChange={(e) => updateFeature('distance_km', parseFloat(e.target.value))}
                style={{ width: '100%', accentColor: '#10b981', cursor: 'pointer' }}
              />
              <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.72rem', color: '#94a3b8' }}>
                <span>0.5 km (Local)</span>
                <span>10 km</span>
                <span>20 km (Long Range)</span>
              </div>
            </div>

            {/* Preparation Time Slider */}
            <div className="form-group">
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '0.4rem' }}>
                <label className="form-label">Kitchen Preparation Time (Preparation_Time_min)</label>
                <span style={{ fontWeight: '700', color: '#0284c7', fontSize: '0.9rem' }}>
                  {features.preparation_time_min} mins
                </span>
              </div>
              <input
                type="range"
                min="5"
                max="30"
                step="1"
                value={features.preparation_time_min}
                onChange={(e) => updateFeature('preparation_time_min', parseInt(e.target.value))}
                style={{ width: '100%', accentColor: '#0284c7', cursor: 'pointer' }}
              />
              <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.72rem', color: '#94a3b8' }}>
                <span>5 mins (Quick snack)</span>
                <span>15 mins</span>
                <span>30 mins (Complex entree)</span>
              </div>
            </div>

            {/* 2-Column Row for Weather and Traffic */}
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem' }}>
              <div className="form-group">
                <label className="form-label">Weather</label>
                <select
                  className="form-select"
                  value={features.weather}
                  onChange={(e) => updateFeature('weather', e.target.value)}
                >
                  <option value="Clear">Clear</option>
                  <option value="Rainy">Rainy</option>
                  <option value="Foggy">Foggy</option>
                  <option value="Snowy">Snowy</option>
                  <option value="Windy">Windy</option>
                </select>
              </div>

              <div className="form-group">
                <label className="form-label">Traffic Level</label>
                <select
                  className="form-select"
                  value={features.traffic_level}
                  onChange={(e) => updateFeature('traffic_level', e.target.value)}
                >
                  <option value="Low">Low</option>
                  <option value="Medium">Medium</option>
                  <option value="High">High</option>
                </select>
              </div>
            </div>

            {/* 2-Column Row for Time of Day and Vehicle Type */}
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem' }}>
              <div className="form-group">
                <label className="form-label">Time of Day</label>
                <select
                  className="form-select"
                  value={features.time_of_day}
                  onChange={(e) => updateFeature('time_of_day', e.target.value)}
                >
                  <option value="Morning">Morning</option>
                  <option value="Afternoon">Afternoon</option>
                  <option value="Evening">Evening</option>
                  <option value="Night">Night</option>
                </select>
              </div>

              <div className="form-group">
                <label className="form-label">Vehicle Type</label>
                <select
                  className="form-select"
                  value={features.vehicle_type}
                  onChange={(e) => updateFeature('vehicle_type', e.target.value)}
                >
                  <option value="Bike">Bike</option>
                  <option value="Scooter">Scooter</option>
                  <option value="Car">Car</option>
                </select>
              </div>
            </div>

            {/* Courier Experience Slider */}
            <div className="form-group">
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '0.4rem' }}>
                <label className="form-label">Courier Experience (Courier_Experience_yrs)</label>
                <span style={{ fontWeight: '700', color: '#7c3aed', fontSize: '0.9rem' }}>
                  {features.courier_experience_yrs} years
                </span>
              </div>
              <input
                type="range"
                min="0"
                max="9"
                step="1"
                value={features.courier_experience_yrs}
                onChange={(e) => updateFeature('courier_experience_yrs', parseInt(e.target.value))}
                style={{ width: '100%', accentColor: '#7c3aed', cursor: 'pointer' }}
              />
              <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.72rem', color: '#94a3b8' }}>
                <span>0 yrs (Novice)</span>
                <span>5 yrs</span>
                <span>9 yrs (Veteran)</span>
              </div>
            </div>

            {/* Submit Button */}
            <button
              type="submit"
              disabled={isLoading}
              className="btn btn-primary"
              style={{
                width: '100%',
                padding: '0.85rem',
                fontSize: '1rem',
                marginTop: '0.5rem'
              }}
            >
              {isLoading ? (
                <>
                  <div style={{
                    width: '18px',
                    height: '18px',
                    border: '2px solid white',
                    borderTopColor: 'transparent',
                    borderRadius: '50%',
                    animation: 'spin 0.8s linear infinite'
                  }} />
                  <span>Querying 4 Models via Flask...</span>
                </>
              ) : (
                <>
                  <Zap size={18} />
                  <span>Predict Delivery Time (All 4 Models)</span>
                </>
              )}
            </button>
          </form>
        </div>
      </div>

      {/* Prediction Results Banner & 4 Model Comparison Cards */}
      {lastPrediction && (
        <div style={{ marginTop: '2.5rem' }} className="fade-in">
          {/* Main Primary Result Card */}
          <div style={{
            background: 'linear-gradient(135deg, #0f172a 0%, #1e293b 100%)',
            color: 'white',
            borderRadius: '20px',
            padding: '2rem 2.25rem',
            marginBottom: '1.75rem',
            boxShadow: 'var(--shadow-xl)',
            border: '1px solid #334155'
          }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', flexWrap: 'wrap', gap: '1.5rem' }}>
              <div>
                <div style={{
                  display: 'inline-flex',
                  alignItems: 'center',
                  gap: '0.4rem',
                  backgroundColor: 'rgba(16, 185, 129, 0.2)',
                  color: '#34d399',
                  padding: '0.3rem 0.75rem',
                  borderRadius: '9999px',
                  fontSize: '0.8rem',
                  fontWeight: '700',
                  marginBottom: '0.85rem'
                }}>
                  <Award size={15} />
                  <span>Best Model: {lastPrediction.best_model.name}</span>
                </div>

                <div style={{ fontSize: '0.9rem', color: '#94a3b8', textTransform: 'uppercase', letterSpacing: '0.05em' }}>
                  Predicted Total Delivery Duration
                </div>
                <div style={{ fontSize: 'clamp(2.5rem, 5vw, 3.75rem)', fontWeight: '800', lineHeight: '1.1', color: 'white', margin: '0.35rem 0' }}>
                  {lastPrediction.best_model.predicted_time_min} <span style={{ fontSize: '1.5rem', color: '#34d399', fontWeight: '600' }}>minutes</span>
                </div>
                <div style={{ fontSize: '1rem', color: '#cbd5e1' }}>
                  Estimated Arrival Time (ETA): <strong style={{ color: '#fbbf24' }}>{lastPrediction.estimated_eta}</strong>
                </div>
              </div>

              {/* Navigation Action Buttons */}
              <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem', minWidth: '220px' }}>
                <button
                  onClick={() => navigate('/tracking')}
                  className="btn btn-primary"
                  style={{ width: '100%', padding: '0.85rem 1.25rem' }}
                >
                  <MapPin size={18} />
                  <span>Simulate Delivery Route</span>
                  <ArrowRight size={16} />
                </button>
                <button
                  onClick={() => navigate('/compare')}
                  className="btn btn-secondary"
                  style={{ width: '100%', backgroundColor: 'rgba(255, 255, 255, 0.1)', color: 'white', borderColor: 'rgba(255, 255, 255, 0.2)' }}
                >
                  <span>Compare All 4 Metrics</span>
                </button>
              </div>
            </div>
          </div>

          {/* 4 Models Side-by-Side Breakdown */}
          <div style={{ marginBottom: '1.5rem' }}>
            <h3 style={{ fontSize: '1.25rem', fontWeight: '800', color: '#0f172a', marginBottom: '0.5rem' }}>
              Multi-Model Prediction Breakdown for this Order
            </h3>
            <p style={{ fontSize: '0.875rem', color: '#64748b', marginBottom: '1.25rem' }}>
              Predictions generated in real time by each distinct scikit-learn regressor for the submitted features:
            </p>

            <div style={{
              display: 'grid',
              gridTemplateColumns: 'repeat(auto-fit, minmax(230px, 1fr))',
              gap: '1.25rem'
            }}>
              {Object.entries(lastPrediction.predictions).map(([key, item]) => {
                const isBest = key === lastPrediction.best_model.key;
                return (
                  <div
                    key={key}
                    className="card"
                    style={{
                      border: isBest ? '2px solid #10b981' : '1px solid var(--border-color)',
                      backgroundColor: isBest ? '#f0fdf4' : 'white',
                      position: 'relative'
                    }}
                  >
                    {isBest && (
                      <span style={{
                        position: 'absolute',
                        top: '-10px',
                        right: '12px',
                        backgroundColor: '#10b981',
                        color: 'white',
                        fontSize: '0.7rem',
                        fontWeight: '700',
                        padding: '0.15rem 0.5rem',
                        borderRadius: '9999px',
                        display: 'flex',
                        alignItems: 'center',
                        gap: '0.2rem'
                      }}>
                        <Award size={11} /> Selected Best
                      </span>
                    )}

                    <div style={{ fontSize: '0.8rem', color: '#64748b', fontWeight: '600', marginBottom: '0.35rem' }}>
                      {item.name}
                    </div>
                    <div style={{ fontSize: '1.75rem', fontWeight: '800', color: isBest ? '#047857' : '#0f172a', marginBottom: '0.5rem' }}>
                      {item.time_min} <span style={{ fontSize: '0.9rem', fontWeight: '600' }}>min</span>
                    </div>

                    <div style={{ fontSize: '0.75rem', color: '#64748b', borderTop: '1px solid #f1f5f9', paddingTop: '0.5rem' }}>
                      Test Set R²: <strong>{item.r2}</strong> • MAE: <strong>±{item.mae} min</strong>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}

      <style>{`
        @keyframes spin {
          to { transform: rotate(360deg); }
        }
      `}</style>
    </div>
  );
}
