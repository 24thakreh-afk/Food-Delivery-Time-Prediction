import React, { useState, useEffect } from 'react';
import { 
  BarChart3, 
  Database, 
  Sliders, 
  CheckCircle2, 
  PieChart as PieIcon, 
  Layers, 
  TrendingUp, 
  Sparkles,
  Info
} from 'lucide-react';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  LineChart,
  Line,
  Cell
} from 'recharts';

export default function Analytics() {
  const [analyticsData, setAnalyticsData] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch('/api/analytics')
      .then(res => res.json())
      .then(data => {
        setAnalyticsData(data);
        setLoading(false);
      })
      .catch(err => {
        console.error('Failed to load analytics data:', err);
        setLoading(false);
      });
  }, []);

  if (loading) {
    return (
      <div style={{ textAlign: 'center', padding: '5rem 0' }}>
        <div style={{
          width: '32px',
          height: '32px',
          border: '3px solid #10b981',
          borderTopColor: 'transparent',
          borderRadius: '50%',
          margin: '0 auto 1rem auto',
          animation: 'spin 0.8s linear infinite'
        }} />
        <p style={{ color: '#64748b' }}>Loading Dataset & Model Insights...</p>
      </div>
    );
  }

  const summary = analyticsData?.dataset_summary || {};
  const metrics = analyticsData?.metrics || {};
  const featureImportances = metrics.feature_importances || [];
  const actualVsPred = metrics.actual_vs_predicted || [];

  // Top 8 features for cleaner bar chart display
  const topFeatures = featureImportances.slice(0, 8);

  return (
    <div className="fade-in">
      {/* Page Header */}
      <div style={{ marginBottom: '2.5rem' }}>
        <div className="badge badge-green" style={{ marginBottom: '0.4rem' }}>
          <BarChart3 size={13} />
          <span>Page 5: Model Insights & Analytics</span>
        </div>
        <h1 style={{ fontSize: '2rem', fontWeight: '800', color: '#0f172a' }}>
          Dataset Summary & Feature Analytics
        </h1>
        <p style={{ color: '#64748b', fontSize: '0.95rem' }}>
          Comprehensive inspection of the genuine 1,000-order training dataset, feature importance weights, and error distributions.
        </p>
      </div>

      {/* Dataset KPI Summary Cards */}
      <div style={{
        display: 'grid',
        gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))',
        gap: '1.25rem',
        marginBottom: '2rem'
      }}>
        <div className="card">
          <div style={{ fontSize: '0.8rem', color: '#64748b', fontWeight: '600', marginBottom: '0.25rem' }}>
            TOTAL OBSERVATIONS
          </div>
          <div style={{ fontSize: '2rem', fontWeight: '800', color: '#0f172a' }}>
            {summary.total_rows || 1000}
          </div>
          <div style={{ fontSize: '0.75rem', color: '#10b981', fontWeight: '600' }}>
            800 Train • 200 Test Split
          </div>
        </div>

        <div className="card">
          <div style={{ fontSize: '0.8rem', color: '#64748b', fontWeight: '600', marginBottom: '0.25rem' }}>
            INPUT FEATURES
          </div>
          <div style={{ fontSize: '2rem', fontWeight: '800', color: '#0f172a' }}>
            7 Features
          </div>
          <div style={{ fontSize: '0.75rem', color: '#0284c7', fontWeight: '600' }}>
            3 Numerical • 4 Categorical
          </div>
        </div>

        <div className="card">
          <div style={{ fontSize: '0.8rem', color: '#64748b', fontWeight: '600', marginBottom: '0.25rem' }}>
            TARGET VARIABLE
          </div>
          <div style={{ fontSize: '1.5rem', fontWeight: '800', color: '#0f172a', lineHeight: '1.4' }}>
            Delivery_Time_min
          </div>
          <div style={{ fontSize: '0.75rem', color: '#64748b' }}>
            Mean: {summary.numerical_ranges?.Delivery_Time_min?.mean?.toFixed(1) || '56.7'} mins
          </div>
        </div>

        <div className="card">
          <div style={{ fontSize: '0.8rem', color: '#64748b', fontWeight: '600', marginBottom: '0.25rem' }}>
            DATA CLEANING
          </div>
          <div style={{ fontSize: '2rem', fontWeight: '800', color: '#10b981' }}>
            100% Imputed
          </div>
          <div style={{ fontSize: '0.75rem', color: '#64748b' }}>
            Median (num) & Mode (cat)
          </div>
        </div>
      </div>

      {/* Feature Inventory & Missing Values Table */}
      <div className="card" style={{ marginBottom: '2.5rem', padding: '0', overflowX: 'auto' }}>
        <div style={{ padding: '1.25rem 1.5rem', borderBottom: '1px solid var(--border-color)' }}>
          <h3 style={{ fontSize: '1.1rem', fontWeight: '800', color: '#0f172a' }}>
            Feature Dictionary & Preprocessing Pipeline
          </h3>
          <p style={{ fontSize: '0.825rem', color: '#64748b' }}>
            Every dataset column, its observed ranges/classes, missing values handled, and transformation strategy.
          </p>
        </div>

        <table style={{ width: '100%', borderCollapse: 'collapse', textAlign: 'left', fontSize: '0.875rem' }}>
          <thead>
            <tr style={{ backgroundColor: '#f8fafc', color: '#475569', fontSize: '0.78rem', textTransform: 'uppercase', letterSpacing: '0.04em' }}>
              <th style={{ padding: '0.75rem 1.25rem' }}>Feature Name</th>
              <th style={{ padding: '0.75rem 1.25rem' }}>Type</th>
              <th style={{ padding: '0.75rem 1.25rem' }}>Observed Values / Range</th>
              <th style={{ padding: '0.75rem 1.25rem' }}>Missing (NaNs)</th>
              <th style={{ padding: '0.75rem 1.25rem' }}>Scikit-Learn Pipeline</th>
            </tr>
          </thead>
          <tbody>
            <tr style={{ borderBottom: '1px solid var(--border-color)' }}>
              <td style={{ padding: '0.85rem 1.25rem', fontWeight: '600' }}>Distance_km</td>
              <td style={{ padding: '0.85rem 1.25rem' }}><span className="badge badge-gray">Float (Num)</span></td>
              <td style={{ padding: '0.85rem 1.25rem' }}>0.59 to 19.99 km</td>
              <td style={{ padding: '0.85rem 1.25rem', color: '#10b981' }}>0</td>
              <td style={{ padding: '0.85rem 1.25rem' }}>SimpleImputer(median) + StandardScaler</td>
            </tr>
            <tr style={{ borderBottom: '1px solid var(--border-color)' }}>
              <td style={{ padding: '0.85rem 1.25rem', fontWeight: '600' }}>Preparation_Time_min</td>
              <td style={{ padding: '0.85rem 1.25rem' }}><span className="badge badge-gray">Integer (Num)</span></td>
              <td style={{ padding: '0.85rem 1.25rem' }}>5 to 29 mins</td>
              <td style={{ padding: '0.85rem 1.25rem', color: '#10b981' }}>0</td>
              <td style={{ padding: '0.85rem 1.25rem' }}>SimpleImputer(median) + StandardScaler</td>
            </tr>
            <tr style={{ borderBottom: '1px solid var(--border-color)' }}>
              <td style={{ padding: '0.85rem 1.25rem', fontWeight: '600' }}>Courier_Experience_yrs</td>
              <td style={{ padding: '0.85rem 1.25rem' }}><span className="badge badge-gray">Float (Num)</span></td>
              <td style={{ padding: '0.85rem 1.25rem' }}>0 to 9 years</td>
              <td style={{ padding: '0.85rem 1.25rem', color: '#f59e0b' }}>30 (3.0%)</td>
              <td style={{ padding: '0.85rem 1.25rem' }}>SimpleImputer(median) + StandardScaler</td>
            </tr>
            <tr style={{ borderBottom: '1px solid var(--border-color)' }}>
              <td style={{ padding: '0.85rem 1.25rem', fontWeight: '600' }}>Weather</td>
              <td style={{ padding: '0.85rem 1.25rem' }}><span className="badge badge-orange">Categorical</span></td>
              <td style={{ padding: '0.85rem 1.25rem' }}>Clear, Foggy, Rainy, Snowy, Windy</td>
              <td style={{ padding: '0.85rem 1.25rem', color: '#f59e0b' }}>30 (3.0%)</td>
              <td style={{ padding: '0.85rem 1.25rem' }}>SimpleImputer(most_frequent) + OneHotEncoder</td>
            </tr>
            <tr style={{ borderBottom: '1px solid var(--border-color)' }}>
              <td style={{ padding: '0.85rem 1.25rem', fontWeight: '600' }}>Traffic_Level</td>
              <td style={{ padding: '0.85rem 1.25rem' }}><span className="badge badge-orange">Categorical</span></td>
              <td style={{ padding: '0.85rem 1.25rem' }}>Low, Medium, High</td>
              <td style={{ padding: '0.85rem 1.25rem', color: '#f59e0b' }}>30 (3.0%)</td>
              <td style={{ padding: '0.85rem 1.25rem' }}>SimpleImputer(most_frequent) + OneHotEncoder</td>
            </tr>
            <tr style={{ borderBottom: '1px solid var(--border-color)' }}>
              <td style={{ padding: '0.85rem 1.25rem', fontWeight: '600' }}>Time_of_Day</td>
              <td style={{ padding: '0.85rem 1.25rem' }}><span className="badge badge-orange">Categorical</span></td>
              <td style={{ padding: '0.85rem 1.25rem' }}>Morning, Afternoon, Evening, Night</td>
              <td style={{ padding: '0.85rem 1.25rem', color: '#f59e0b' }}>30 (3.0%)</td>
              <td style={{ padding: '0.85rem 1.25rem' }}>SimpleImputer(most_frequent) + OneHotEncoder</td>
            </tr>
            <tr style={{ borderBottom: '1px solid var(--border-color)' }}>
              <td style={{ padding: '0.85rem 1.25rem', fontWeight: '600' }}>Vehicle_Type</td>
              <td style={{ padding: '0.85rem 1.25rem' }}><span className="badge badge-orange">Categorical</span></td>
              <td style={{ padding: '0.85rem 1.25rem' }}>Bike, Scooter, Car</td>
              <td style={{ padding: '0.85rem 1.25rem', color: '#10b981' }}>0</td>
              <td style={{ padding: '0.85rem 1.25rem' }}>SimpleImputer(most_frequent) + OneHotEncoder</td>
            </tr>
          </tbody>
        </table>
      </div>

      {/* Two-Column Grid: Feature Importance & Actual vs Predicted */}
      <div style={{
        display: 'grid',
        gridTemplateColumns: 'repeat(auto-fit, minmax(340px, 1fr))',
        gap: '2rem',
        marginBottom: '2.5rem'
      }}>
        {/* Random Forest Feature Importance */}
        <div className="card">
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', marginBottom: '0.5rem' }}>
            <Sparkles size={18} color="#10b981" />
            <h3 style={{ fontSize: '1.15rem', fontWeight: '800', color: '#0f172a' }}>
              Random Forest Feature Importance (%)
            </h3>
          </div>
          <p style={{ fontSize: '0.825rem', color: '#64748b', marginBottom: '1.25rem' }}>
            Calculated via mean decrease in impurity across all 100 decision trees in the ensemble.
          </p>

          <div style={{ width: '100%', height: '300px' }}>
            <ResponsiveContainer width="100%" height="100%">
              <BarChart layout="vertical" data={topFeatures} margin={{ top: 10, right: 30, left: 70, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                <XAxis type="number" tick={{ fontSize: 11, fill: '#64748b' }} unit="%" />
                <YAxis dataKey="feature" type="category" tick={{ fontSize: 11, fill: '#334155' }} />
                <Tooltip formatter={(val) => [`${val}%`, 'Importance Weight']} />
                <Bar dataKey="importance" fill="#10b981" radius={[0, 6, 6, 0]}>
                  {topFeatures.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={index === 0 ? '#10b981' : index === 1 ? '#0284c7' : '#94a3b8'} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>

          <div style={{ fontSize: '0.8rem', color: '#475569', marginTop: '0.75rem', lineHeight: '1.5' }}>
            <strong>Dominant Factor:</strong> Distance accounts for <strong>{featureImportances[0]?.importance}%</strong> of prediction weighting, followed by kitchen preparation time at <strong>{featureImportances[1]?.importance}%</strong>.
          </div>
        </div>

        {/* Actual vs Predicted on Held-Out Test Data */}
        <div className="card">
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', marginBottom: '0.5rem' }}>
            <TrendingUp size={18} color="#0284c7" />
            <h3 style={{ fontSize: '1.15rem', fontWeight: '800', color: '#0f172a' }}>
              Actual vs. Predicted Delivery Times
            </h3>
          </div>
          <p style={{ fontSize: '0.825rem', color: '#64748b', marginBottom: '1.25rem' }}>
            Sample of 40 held-out test orders comparing actual delivery minutes against model predictions.
          </p>

          <div style={{ width: '100%', height: '300px' }}>
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={actualVsPred} margin={{ top: 10, right: 30, left: 0, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                <XAxis dataKey="sample_id" tick={{ fontSize: 11, fill: '#64748b' }} label={{ value: 'Test Sample #', position: 'insideBottom', offset: -5, fontSize: 10 }} />
                <YAxis tick={{ fontSize: 11, fill: '#64748b' }} unit="m" />
                <Tooltip />
                <Line type="monotone" dataKey="actual" stroke="#0f172a" strokeWidth={2} dot={false} name="Actual (mins)" />
                <Line type="monotone" dataKey="predicted" stroke="#10b981" strokeWidth={2} strokeDasharray="4 4" dot={false} name="Predicted (mins)" />
              </LineChart>
            </ResponsiveContainer>
          </div>

          <div style={{ fontSize: '0.8rem', color: '#475569', marginTop: '0.75rem', lineHeight: '1.5' }}>
            The predicted curve closely traces the real test observations across short, medium, and long delivery journeys with tight error bounds.
          </div>
        </div>
      </div>
    </div>
  );
}
