import React from 'react';
import { Link } from 'react-router-dom';
import { 
  Zap, 
  ArrowRight, 
  Clock, 
  TrendingUp, 
  MapPin, 
  CheckCircle2, 
  Cpu, 
  Star, 
  Flame,
  ShieldCheck,
  BarChart3,
  GitCompare,
  Layers
} from 'lucide-react';
import { SAMPLE_RESTAURANTS, useOrder } from '../context/OrderContext';

export default function Home() {
  const { setSelectedRestaurant } = useOrder();

  const fourModels = [
    {
      name: 'Linear Regression',
      type: 'Parametric Linear Baseline',
      desc: 'Fits an optimal hyperplane modeling direct linear relationships between delivery distance, prep time, and transit duration.',
      tag: 'Best MAE: 6.06 min',
      color: '#10b981',
      bgColor: '#ecfdf5'
    },
    {
      name: 'Random Forest Regressor',
      type: 'Ensemble Bagging Trees',
      desc: 'Ensemble of 100 de-correlated decision trees that captures complex non-linear feature interactions without overfitting.',
      tag: 'MAE: 6.77 min',
      color: '#0284c7',
      bgColor: '#f0f9ff'
    },
    {
      name: 'K-Nearest Neighbors (KNN)',
      type: 'Instance-Based Distance Metric',
      desc: 'Predicts delivery minutes by finding the 7 most similar historical orders in normalized Euclidean feature space.',
      tag: 'MAE: 8.30 min',
      color: '#7c3aed',
      bgColor: '#f5f3ff'
    },
    {
      name: 'Decision Tree Regressor',
      type: 'Recursive Partitioning',
      desc: 'Partitions data into orthogonal decision rules based on distance, weather, and preparation time splits.',
      tag: 'MAE: 8.51 min',
      color: '#ea580c',
      bgColor: '#fff7ed'
    }
  ];

  return (
    <div className="fade-in">
      {/* Hero Section */}
      <section style={{
        position: 'relative',
        backgroundColor: '#ffffff',
        borderRadius: '24px',
        border: '1px solid var(--border-color)',
        padding: '3.5rem 2.5rem',
        marginBottom: '3rem',
        overflow: 'hidden',
        boxShadow: '0 4px 20px -2px rgba(0, 0, 0, 0.05)'
      }}>
        {/* Subtle Decorative Background Blob */}
        <div style={{
          position: 'absolute',
          top: '-20%',
          right: '-10%',
          width: '500px',
          height: '500px',
          background: 'radial-gradient(circle, rgba(16, 185, 129, 0.12) 0%, rgba(255, 255, 255, 0) 70%)',
          borderRadius: '50%',
          pointerEvents: 'none'
        }} />

        <div style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fit, minmax(320px, 1fr))',
          gap: '3rem',
          alignItems: 'center',
          position: 'relative',
          zIndex: 1
        }}>
          {/* Left Column: Headline and Call-to-Action */}
          <div>
            <div style={{
              display: 'inline-flex',
              alignItems: 'center',
              gap: '0.5rem',
              backgroundColor: '#ecfdf5',
              color: '#047857',
              border: '1px solid #a7f3d0',
              padding: '0.35rem 0.85rem',
              borderRadius: '9999px',
              fontSize: '0.8rem',
              fontWeight: '700',
              marginBottom: '1.25rem'
            }}>
              <Flame size={15} fill="#10b981" />
              <span>Machine Learning Powered Food Delivery</span>
            </div>

            <h1 style={{
              fontSize: 'clamp(2.2rem, 4vw, 3.25rem)',
              fontWeight: '800',
              lineHeight: '1.15',
              color: '#0f172a',
              marginBottom: '1.25rem',
              letterSpacing: '-0.03em'
            }}>
              Precision Delivery ETA Predictor with <span style={{ color: '#10b981' }}>4 ML Models</span>
            </h1>

            <p style={{
              fontSize: '1.1rem',
              lineHeight: '1.6',
              color: '#475569',
              marginBottom: '2rem'
            }}>
              Experience realistic food ordering paired with rigorous academic machine learning. Predict delivery times in minutes across varying traffic, weather, distance, and kitchen prep times.
            </p>

            <div style={{ display: 'flex', gap: '1rem', flexWrap: 'wrap', alignItems: 'center' }}>
              <Link to="/predict" className="btn btn-primary" style={{ padding: '0.9rem 1.75rem', fontSize: '1rem' }}>
                <Zap size={18} />
                <span>Predict Delivery Time</span>
                <ArrowRight size={16} />
              </Link>
              <Link to="/compare" className="btn btn-secondary" style={{ padding: '0.9rem 1.5rem', fontSize: '1rem' }}>
                <GitCompare size={18} />
                <span>Compare 4 Models</span>
              </Link>
            </div>

            {/* Quick Stats Badges */}
            <div style={{
              display: 'flex',
              gap: '1.5rem',
              marginTop: '2.5rem',
              paddingTop: '1.5rem',
              borderTop: '1px solid #f1f5f9',
              flexWrap: 'wrap'
            }}>
              <div>
                <div style={{ fontSize: '1.35rem', fontWeight: '800', color: '#0f172a' }}>1,000</div>
                <div style={{ fontSize: '0.78rem', color: '#64748b' }}>Real Orders Dataset</div>
              </div>
              <div style={{ width: '1px', backgroundColor: '#e2e8f0' }} />
              <div>
                <div style={{ fontSize: '1.35rem', fontWeight: '800', color: '#10b981' }}>±6.06 min</div>
                <div style={{ fontSize: '0.78rem', color: '#64748b' }}>Best Test MAE</div>
              </div>
              <div style={{ width: '1px', backgroundColor: '#e2e8f0' }} />
              <div>
                <div style={{ fontSize: '1.35rem', fontWeight: '800', color: '#0f172a' }}>4 Models</div>
                <div style={{ fontSize: '0.78rem', color: '#64748b' }}>Evaluated in Parallel</div>
              </div>
            </div>
          </div>

          {/* Right Column: Hero Visual Card */}
          <div style={{ position: 'relative' }}>
            <div style={{
              borderRadius: '20px',
              overflow: 'hidden',
              boxShadow: '0 20px 30px -10px rgba(0, 0, 0, 0.12)',
              border: '4px solid white'
            }}>
              <img
                src="https://images.unsplash.com/photo-1504674900247-0877df9cc836?w=800&auto=format&fit=crop&q=80"
                alt="Delicious Gourmet Food Delivery"
                style={{ width: '100%', height: '360px', objectFit: 'cover', display: 'block' }}
              />
            </div>

            {/* Floating Live Prediction Badge */}
            <div style={{
              position: 'absolute',
              bottom: '-15px',
              left: '20px',
              backgroundColor: 'white',
              borderRadius: '14px',
              padding: '1rem 1.25rem',
              boxShadow: '0 10px 25px -5px rgba(0, 0, 0, 0.15)',
              border: '1px solid #e2e8f0',
              display: 'flex',
              alignItems: 'center',
              gap: '1rem',
              maxWidth: '300px'
            }}>
              <div style={{
                width: '44px',
                height: '44px',
                borderRadius: '12px',
                backgroundColor: '#ecfdf5',
                color: '#10b981',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                flexShrink: 0
              }}>
                <Clock size={24} />
              </div>
              <div>
                <div style={{ fontSize: '0.75rem', color: '#64748b', fontWeight: '600', textTransform: 'uppercase' }}>
                  Predicted Delivery
                </div>
                <div style={{ fontSize: '1.25rem', fontWeight: '800', color: '#0f172a' }}>
                  28.5 mins <span style={{ fontSize: '0.85rem', color: '#10b981', fontWeight: '700' }}>• On Time</span>
                </div>
                <div style={{ fontSize: '0.72rem', color: '#94a3b8' }}>
                  Via Linear Regressor & Random Forest
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Featured Restaurants Section */}
      <section style={{ marginBottom: '3.5rem' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end', marginBottom: '1.5rem', flexWrap: 'wrap', gap: '1rem' }}>
          <div>
            <div className="badge badge-orange" style={{ marginBottom: '0.4rem' }}>
              <Flame size={12} />
              <span>Partner Kitchens</span>
            </div>
            <h2 style={{ fontSize: '1.75rem', fontWeight: '800', color: '#0f172a' }}>
              Select a Restaurant to Start Predicting
            </h2>
            <p style={{ fontSize: '0.925rem', color: '#64748b' }}>
              Pick from our sample curated kitchens or customize distance and preparation time directly.
            </p>
          </div>
          <Link to="/predict" className="btn btn-secondary" style={{ fontSize: '0.85rem' }}>
            <span>View Full Menu & Cart</span>
            <ArrowRight size={14} />
          </Link>
        </div>

        <div style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fit, minmax(260px, 1fr))',
          gap: '1.5rem'
        }}>
          {SAMPLE_RESTAURANTS.map((rest) => (
            <div
              key={rest.id}
              className="card"
              style={{
                padding: '0',
                overflow: 'hidden',
                display: 'flex',
                flexDirection: 'column',
                cursor: 'pointer'
              }}
              onClick={() => setSelectedRestaurant(rest)}
            >
              <div style={{ position: 'relative', height: '160px' }}>
                <img
                  src={rest.image}
                  alt={rest.name}
                  style={{ width: '100%', height: '100%', objectFit: 'cover' }}
                />
                <span style={{
                  position: 'absolute',
                  top: '12px',
                  right: '12px',
                  backgroundColor: 'rgba(15, 23, 42, 0.85)',
                  color: 'white',
                  fontSize: '0.75rem',
                  fontWeight: '700',
                  padding: '0.2rem 0.6rem',
                  borderRadius: '9999px',
                  backdropFilter: 'blur(4px)'
                }}>
                  {rest.tag}
                </span>
              </div>
              <div style={{ padding: '1.25rem', display: 'flex', flexDirection: 'column', flex: 1 }}>
                <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '0.35rem' }}>
                  <h3 style={{ fontSize: '1.05rem', fontWeight: '700', color: '#0f172a' }}>{rest.name}</h3>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '0.25rem', color: '#f59e0b', fontSize: '0.85rem', fontWeight: '700' }}>
                    <Star size={14} fill="#f59e0b" />
                    <span>{rest.rating}</span>
                  </div>
                </div>
                <div style={{ fontSize: '0.825rem', color: '#64748b', marginBottom: '1rem' }}>
                  {rest.cuisine}
                </div>
                <div style={{
                  marginTop: 'auto',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'space-between',
                  paddingTop: '0.75rem',
                  borderTop: '1px solid #f1f5f9',
                  fontSize: '0.8rem',
                  color: '#475569'
                }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '0.3rem' }}>
                    <Clock size={14} color="#10b981" />
                    <span>{rest.prepTime} min prep</span>
                  </div>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '0.3rem' }}>
                    <MapPin size={14} color="#f97316" />
                    <span>{rest.distanceKm} km away</span>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* How Intelligent Prediction Works */}
      <section style={{
        backgroundColor: '#f8fafc',
        borderRadius: '20px',
        padding: '3rem 2rem',
        border: '1px solid var(--border-color)',
        marginBottom: '3.5rem'
      }}>
        <div style={{ textAlign: 'center', maxWidth: '650px', margin: '0 auto 2.5rem auto' }}>
          <div className="badge badge-green" style={{ marginBottom: '0.5rem' }}>
            <Cpu size={12} />
            <span>Architecture & Workflow</span>
          </div>
          <h2 style={{ fontSize: '1.85rem', fontWeight: '800', color: '#0f172a', marginBottom: '0.5rem' }}>
            How DeliverIQ Predicts Delivery Times
          </h2>
          <p style={{ fontSize: '0.95rem', color: '#64748b' }}>
            A transparent 3-step pipeline taking live simulated orders and applying mathematical regression to output accurate arrival times.
          </p>
        </div>

        <div style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))',
          gap: '1.75rem'
        }}>
          <div className="card" style={{ backgroundColor: 'white' }}>
            <div style={{
              width: '40px',
              height: '40px',
              borderRadius: '10px',
              backgroundColor: '#ecfdf5',
              color: '#10b981',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              fontWeight: '800',
              marginBottom: '1rem'
            }}>
              1
            </div>
            <h3 style={{ fontSize: '1.1rem', fontWeight: '700', marginBottom: '0.5rem' }}>
              Feature Input Collection
            </h3>
            <p style={{ fontSize: '0.875rem', color: '#64748b', lineHeight: '1.6' }}>
              Accepts 7 genuine dataset variables: Distance, Weather condition, Traffic level, Time of Day, Vehicle type, Kitchen prep time, and Courier experience.
            </p>
          </div>

          <div className="card" style={{ backgroundColor: 'white' }}>
            <div style={{
              width: '40px',
              height: '40px',
              borderRadius: '10px',
              backgroundColor: '#f0f9ff',
              color: '#0284c7',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              fontWeight: '800',
              marginBottom: '1rem'
            }}>
              2
            </div>
            <h3 style={{ fontSize: '1.1rem', fontWeight: '700', marginBottom: '0.5rem' }}>
              Preprocessing & Model Inference
            </h3>
            <p style={{ fontSize: '0.875rem', color: '#64748b', lineHeight: '1.6' }}>
              The Flask backend applies standard scaling and one-hot encoding pipelines, then runs all 4 regression models in real-time to compute individual predictions.
            </p>
          </div>

          <div className="card" style={{ backgroundColor: 'white' }}>
            <div style={{
              width: '40px',
              height: '40px',
              borderRadius: '10px',
              backgroundColor: '#faf5ff',
              color: '#9333ea',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              fontWeight: '800',
              marginBottom: '1rem'
            }}>
              3
            </div>
            <h3 style={{ fontSize: '1.1rem', fontWeight: '700', marginBottom: '0.5rem' }}>
              Best Model Selection & ETA
            </h3>
            <p style={{ fontSize: '0.875rem', color: '#64748b', lineHeight: '1.6' }}>
              Selects the optimal model based on held-out test set accuracy (lowest MAE), renders interactive comparisons, and generates a live tracking simulation.
            </p>
          </div>
        </div>
      </section>

      {/* The 4 Machine Learning Models Preview */}
      <section style={{ marginBottom: '3.5rem' }}>
        <div style={{ textAlign: 'center', maxWidth: '650px', margin: '0 auto 2.5rem auto' }}>
          <div className="badge badge-gray" style={{ marginBottom: '0.5rem' }}>
            <Layers size={12} />
            <span>Algorithms Evaluated</span>
          </div>
          <h2 style={{ fontSize: '1.85rem', fontWeight: '800', color: '#0f172a', marginBottom: '0.5rem' }}>
            The Four Regression Models
          </h2>
          <p style={{ fontSize: '0.95rem', color: '#64748b' }}>
            All four models were trained on the exact same 800 training samples and evaluated on the same 200 held-out test cases.
          </p>
        </div>

        <div style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fit, minmax(260px, 1fr))',
          gap: '1.5rem'
        }}>
          {fourModels.map((m, idx) => (
            <div
              key={idx}
              className="card"
              style={{
                borderLeft: `4px solid ${m.color}`,
                display: 'flex',
                flexDirection: 'column'
              }}
            >
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '0.75rem' }}>
                <span style={{
                  fontSize: '0.75rem',
                  fontWeight: '700',
                  padding: '0.2rem 0.5rem',
                  borderRadius: '6px',
                  backgroundColor: m.bgColor,
                  color: m.color
                }}>
                  {m.tag}
                </span>
                <span style={{ fontSize: '0.75rem', color: '#94a3b8', fontWeight: '600' }}>#{idx + 1}</span>
              </div>
              <h3 style={{ fontSize: '1.15rem', fontWeight: '700', color: '#0f172a', marginBottom: '0.25rem' }}>
                {m.name}
              </h3>
              <div style={{ fontSize: '0.78rem', color: '#64748b', fontWeight: '600', marginBottom: '0.75rem' }}>
                {m.type}
              </div>
              <p style={{ fontSize: '0.85rem', color: '#475569', lineHeight: '1.55', flex: 1, marginBottom: '1.25rem' }}>
                {m.desc}
              </p>
              <Link to="/compare" style={{ fontSize: '0.825rem', fontWeight: '700', color: m.color, display: 'flex', alignItems: 'center', gap: '0.35rem' }}>
                <span>Inspect model metrics</span>
                <ArrowRight size={14} />
              </Link>
            </div>
          ))}
        </div>
      </section>

      {/* Analytics & Comparison Teaser Banner */}
      <section style={{
        backgroundColor: '#0f172a',
        color: 'white',
        borderRadius: '20px',
        padding: '3rem 2.5rem',
        display: 'flex',
        flexWrap: 'wrap',
        alignItems: 'center',
        justifyContent: 'space-between',
        gap: '2rem'
      }}>
        <div style={{ maxWidth: '580px' }}>
          <div style={{
            display: 'inline-flex',
            alignItems: 'center',
            gap: '0.4rem',
            backgroundColor: 'rgba(16, 185, 129, 0.2)',
            color: '#34d399',
            padding: '0.25rem 0.65rem',
            borderRadius: '9999px',
            fontSize: '0.75rem',
            fontWeight: '700',
            marginBottom: '0.75rem'
          }}>
            <BarChart3 size={13} />
            <span>Interactive Analytics & History</span>
          </div>
          <h2 style={{ fontSize: '1.85rem', fontWeight: '800', lineHeight: '1.2', marginBottom: '0.75rem' }}>
            Dive Deep into Model Insights & Prediction History
          </h2>
          <p style={{ fontSize: '0.95rem', color: '#94a3b8', lineHeight: '1.6' }}>
            Inspect Random Forest feature importance rankings, actual vs. predicted distributions, and review stored SQLite order records anytime.
          </p>
        </div>
        <div style={{ display: 'flex', gap: '1rem', flexWrap: 'wrap' }}>
          <Link to="/analytics" className="btn btn-primary" style={{ padding: '0.85rem 1.5rem' }}>
            <BarChart3 size={16} />
            <span>Open Model Analytics</span>
          </Link>
          <Link to="/history" className="btn btn-secondary" style={{ backgroundColor: 'rgba(255, 255, 255, 0.1)', color: 'white', borderColor: 'rgba(255, 255, 255, 0.2)', padding: '0.85rem 1.5rem' }}>
            <span>View Saved History</span>
          </Link>
        </div>
      </section>
    </div>
  );
}
