import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { 
  GitCompare, 
  Award, 
  BarChart2, 
  Info, 
  HelpCircle, 
  ArrowRight, 
  CheckCircle2, 
  Zap,
  TrendingDown,
  TrendingUp,
  Activity
} from 'lucide-react';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend, 
  ResponsiveContainer,
  Cell
} from 'recharts';
import { useOrder } from '../context/OrderContext';

export default function ModelComparison() {
  const { lastPrediction, features } = useOrder();
  const [metricsData, setMetricsData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [selectedMetricTab, setSelectedMetricTab] = useState('mae'); // 'mae' | 'rmse' | 'r2'

  useEffect(() => {
    fetch('/api/models/metrics')
      .then(res => res.json())
      .then(data => {
        setMetricsData(data);
        setLoading(false);
      })
      .catch(err => {
        console.error('Failed to load metrics:', err);
        setLoading(false);
      });
  }, []);

  // Format Recharts data from overall test metrics
  const chartData = metricsData ? Object.values(metricsData.models).map(m => ({
    name: m.name.replace(' Regressor', '').replace(' (KNN)', ''),
    fullName: m.name,
    MAE: m.mae,
    RMSE: m.rmse,
    MSE: m.mse,
    R2: m.r2,
    id: m.id
  })) : [];

  const getMetricExplanation = (metric) => {
    switch (metric) {
      case 'mae':
        return {
          title: 'Mean Absolute Error (MAE)',
          direction: 'Lower is Better',
          directionType: 'lower',
          desc: 'The average absolute difference between predicted delivery minutes and actual delivery minutes. For example, an MAE of 6.06 min means predictions are off by only about 6 minutes on average.'
        };
      case 'rmse':
        return {
          title: 'Root Mean Squared Error (RMSE)',
          direction: 'Lower is Better',
          directionType: 'lower',
          desc: 'Calculates the square root of the average squared errors. RMSE penalizes large errors more heavily than MAE, highlighting severe delivery delays or mispredictions.'
        };
      case 'r2':
        return {
          title: 'Coefficient of Determination (R² Score)',
          direction: 'Higher is Better (Max 1.0)',
          directionType: 'higher',
          desc: 'Measures the proportion of delivery time variance explained by the features (distance, weather, prep time). An R² of 0.82 means 82% of transit time variations are successfully captured by the model.'
        };
      default:
        return {};
    }
  };

  const currentMetricInfo = getMetricExplanation(selectedMetricTab);

  return (
    <div className="fade-in">
      {/* Top Page Header */}
      <div style={{ marginBottom: '2.5rem' }}>
        <div className="badge badge-green" style={{ marginBottom: '0.4rem' }}>
          <GitCompare size={13} />
          <span>Page 4: Machine Learning Model Comparison</span>
        </div>
        <h1 style={{ fontSize: '2rem', fontWeight: '800', color: '#0f172a' }}>
          Evaluate & Compare All 4 Regression Models
        </h1>
        <p style={{ color: '#64748b', fontSize: '0.95rem' }}>
          Comparing predictions on your active order alongside genuine held-out test evaluation benchmarks (MAE, RMSE, R²).
        </p>
      </div>

      {/* SECTION A: Individual Order Prediction Comparison */}
      <section style={{ marginBottom: '3.5rem' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1rem', flexWrap: 'wrap', gap: '0.75rem' }}>
          <div>
            <h2 style={{ fontSize: '1.4rem', fontWeight: '800', color: '#0f172a' }}>
              Section A: Predictions on Active Order
            </h2>
            <p style={{ fontSize: '0.85rem', color: '#64748b' }}>
              Current Features: {features.distance_km} km • {features.weather} Weather • {features.traffic_level} Traffic • {features.vehicle_type} • {features.preparation_time_min} min prep
            </p>
          </div>
          <Link to="/predict" className="btn btn-secondary" style={{ fontSize: '0.85rem' }}>
            <span>Modify Order Inputs</span>
            <ArrowRight size={14} />
          </Link>
        </div>

        {lastPrediction ? (
          <div style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fit, minmax(250px, 1fr))',
            gap: '1.25rem',
            marginBottom: '1.5rem'
          }}>
            {Object.entries(lastPrediction.predictions).map(([key, item]) => {
              const isBest = key === lastPrediction.best_model.key;
              return (
                <div
                  key={key}
                  className="card"
                  style={{
                    border: isBest ? '2px solid #10b981' : '1px solid var(--border-color)',
                    backgroundColor: isBest ? '#f0fdf4' : 'white',
                    position: 'relative'
                  }}
                >
                  {isBest && (
                    <span style={{
                      position: 'absolute',
                      top: '-10px',
                      right: '12px',
                      backgroundColor: '#10b981',
                      color: 'white',
                      fontSize: '0.7rem',
                      fontWeight: '700',
                      padding: '0.15rem 0.5rem',
                      borderRadius: '9999px',
                      display: 'flex',
                      alignItems: 'center',
                      gap: '0.2rem'
                    }}>
                      <Award size={11} /> Top Test Performer
                    </span>
                  )}
                  <div style={{ fontSize: '0.85rem', fontWeight: '700', color: '#64748b', marginBottom: '0.35rem' }}>
                    {item.name}
                  </div>
                  <div style={{ fontSize: '2.25rem', fontWeight: '800', color: isBest ? '#047857' : '#0f172a', marginBottom: '0.5rem' }}>
                    {item.time_min} <span style={{ fontSize: '1rem', fontWeight: '600' }}>min</span>
                  </div>
                  <div style={{ fontSize: '0.75rem', color: '#64748b', borderTop: '1px solid #f1f5f9', paddingTop: '0.5rem' }}>
                    Held-out Test MAE: <strong>±{item.mae} min</strong>
                  </div>
                </div>
              );
            })}
          </div>
        ) : (
          <div className="card" style={{ backgroundColor: '#f8fafc', padding: '1.75rem', textAlign: 'center', marginBottom: '1.5rem' }}>
            <p style={{ color: '#64748b', fontSize: '0.925rem', marginBottom: '0.75rem' }}>
              No custom order submitted yet. Submit an order on the Prediction page to compare live inference results across all 4 models.
            </p>
            <Link to="/predict" className="btn btn-primary" style={{ display: 'inline-flex', padding: '0.65rem 1.25rem' }}>
              <Zap size={15} />
              <span>Configure Sample Order</span>
            </Link>
          </div>
        )}

        {/* Why Model Predictions Differ Note */}
        <div style={{
          backgroundColor: '#f8fafc',
          border: '1px solid #e2e8f0',
          borderRadius: '12px',
          padding: '1.25rem',
          fontSize: '0.875rem',
          lineHeight: '1.6',
          color: '#334155'
        }}>
          <strong style={{ color: '#0f172a', display: 'flex', alignItems: 'center', gap: '0.4rem', marginBottom: '0.35rem' }}>
            <Info size={16} color="#0284c7" />
            Why do individual predictions differ between models?
          </strong>
          Linear Regression models direct proportional travel and prep slopes. Decision Trees partition feature space into discrete step intervals (creating stair-step outputs). K-Nearest Neighbors (KNN) calculates local averages of the 7 nearest orders in normalized feature space. Random Forest averages 100 decorrelated trees, smoothing out decision tree variance while preserving non-linear boundaries.
        </div>
      </section>

      {/* SECTION B: Overall Model Performance on Held-Out Test Data */}
      <section>
        <div style={{ marginBottom: '1.25rem' }}>
          <div className="badge badge-orange" style={{ marginBottom: '0.35rem' }}>
            <BarChart2 size={13} />
            <span>Held-Out Test Set Evaluation</span>
          </div>
          <h2 style={{ fontSize: '1.5rem', fontWeight: '800', color: '#0f172a' }}>
            Section B: Benchmark Evaluation Metrics (N = 200 Test Cases)
          </h2>
          <p style={{ fontSize: '0.9rem', color: '#64748b' }}>
            Calculated on identical held-out test records to strictly prevent data leakage and provide fair comparison.
          </p>
        </div>

        {/* Comparison Table */}
        <div className="card" style={{ padding: '0', overflowX: 'auto', marginBottom: '2rem' }}>
          <table style={{ width: '100%', borderCollapse: 'collapse', textAlign: 'left', fontSize: '0.9rem' }}>
            <thead>
              <tr style={{ backgroundColor: '#f8fafc', borderBottom: '1px solid var(--border-color)', color: '#475569', fontSize: '0.8rem', textTransform: 'uppercase', letterSpacing: '0.05em' }}>
                <th style={{ padding: '0.9rem 1.25rem' }}>Model Name</th>
                <th style={{ padding: '0.9rem 1.25rem' }}>MAE (min) ↓</th>
                <th style={{ padding: '0.9rem 1.25rem' }}>MSE ↓</th>
                <th style={{ padding: '0.9rem 1.25rem' }}>RMSE (min) ↓</th>
                <th style={{ padding: '0.9rem 1.25rem' }}>R² Score ↑</th>
                <th style={{ padding: '0.9rem 1.25rem' }}>Rank & Verdict</th>
              </tr>
            </thead>
            <tbody>
              {chartData.map((m, idx) => {
                const isBest = metricsData && metricsData.best_model === m.id;
                return (
                  <tr
                    key={m.id}
                    style={{
                      borderBottom: '1px solid var(--border-color)',
                      backgroundColor: isBest ? '#f0fdf4' : 'transparent',
                      fontWeight: isBest ? '600' : 'normal'
                    }}
                  >
                    <td style={{ padding: '1rem 1.25rem', color: isBest ? '#047857' : '#0f172a' }}>
                      <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                        {isBest && <Award size={16} color="#10b981" />}
                        <span>{m.fullName}</span>
                      </div>
                    </td>
                    <td style={{ padding: '1rem 1.25rem' }}>
                      <span style={{ fontWeight: '700', color: isBest ? '#10b981' : '#0f172a' }}>
                        {m.MAE}
                      </span>
                    </td>
                    <td style={{ padding: '1rem 1.25rem', color: '#64748b' }}>{m.MSE}</td>
                    <td style={{ padding: '1rem 1.25rem' }}>{m.RMSE}</td>
                    <td style={{ padding: '1rem 1.25rem' }}>
                      <span style={{ fontWeight: '700', color: isBest ? '#10b981' : '#0f172a' }}>
                        {m.R2}
                      </span>
                    </td>
                    <td style={{ padding: '1rem 1.25rem' }}>
                      {isBest ? (
                        <span className="badge badge-green">★ 1st Place (Winner)</span>
                      ) : (
                        <span className="badge badge-gray">Rank #{idx + 1}</span>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        {/* Interactive Comparison Chart with Metric Tabs */}
        <div className="card" style={{ marginBottom: '2rem' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1.5rem', flexWrap: 'wrap', gap: '1rem' }}>
            <div>
              <h3 style={{ fontSize: '1.15rem', fontWeight: '800', color: '#0f172a' }}>
                Interactive Metric Comparison Chart
              </h3>
              <div style={{ fontSize: '0.8rem', color: '#64748b' }}>
                Switch between evaluation metrics to compare model rankings visually.
              </div>
            </div>

            {/* Metric Tabs */}
            <div style={{ display: 'flex', gap: '0.35rem', backgroundColor: '#f1f5f9', padding: '0.25rem', borderRadius: '8px' }}>
              <button
                onClick={() => setSelectedMetricTab('mae')}
                style={{
                  padding: '0.45rem 0.85rem',
                  borderRadius: '6px',
                  border: 'none',
                  backgroundColor: selectedMetricTab === 'mae' ? 'white' : 'transparent',
                  color: selectedMetricTab === 'mae' ? '#0f172a' : '#64748b',
                  fontWeight: '700',
                  fontSize: '0.8rem',
                  cursor: 'pointer',
                  boxShadow: selectedMetricTab === 'mae' ? 'var(--shadow-sm)' : 'none'
                }}
              >
                MAE (Lower is Better)
              </button>
              <button
                onClick={() => setSelectedMetricTab('rmse')}
                style={{
                  padding: '0.45rem 0.85rem',
                  borderRadius: '6px',
                  border: 'none',
                  backgroundColor: selectedMetricTab === 'rmse' ? 'white' : 'transparent',
                  color: selectedMetricTab === 'rmse' ? '#0f172a' : '#64748b',
                  fontWeight: '700',
                  fontSize: '0.8rem',
                  cursor: 'pointer',
                  boxShadow: selectedMetricTab === 'rmse' ? 'var(--shadow-sm)' : 'none'
                }}
              >
                RMSE (Lower is Better)
              </button>
              <button
                onClick={() => setSelectedMetricTab('r2')}
                style={{
                  padding: '0.45rem 0.85rem',
                  borderRadius: '6px',
                  border: 'none',
                  backgroundColor: selectedMetricTab === 'r2' ? 'white' : 'transparent',
                  color: selectedMetricTab === 'r2' ? '#0f172a' : '#64748b',
                  fontWeight: '700',
                  fontSize: '0.8rem',
                  cursor: 'pointer',
                  boxShadow: selectedMetricTab === 'r2' ? 'var(--shadow-sm)' : 'none'
                }}
              >
                R² Score (Higher is Better)
              </button>
            </div>
          </div>

          {/* Metric Description Card */}
          <div style={{
            backgroundColor: currentMetricInfo.directionType === 'lower' ? '#ecfdf5' : '#eff6ff',
            border: `1px solid ${currentMetricInfo.directionType === 'lower' ? '#a7f3d0' : '#bfdbfe'}`,
            borderRadius: '8px',
            padding: '0.85rem 1rem',
            marginBottom: '1.5rem',
            fontSize: '0.85rem',
            display: 'flex',
            alignItems: 'center',
            gap: '0.75rem'
          }}>
            {currentMetricInfo.directionType === 'lower' ? (
              <TrendingDown size={20} color="#047857" style={{ flexShrink: 0 }} />
            ) : (
              <TrendingUp size={20} color="#1d4ed8" style={{ flexShrink: 0 }} />
            )}
            <div>
              <strong style={{ color: '#0f172a' }}>{currentMetricInfo.title} ({currentMetricInfo.direction}):</strong>{' '}
              <span style={{ color: '#334155' }}>{currentMetricInfo.desc}</span>
            </div>
          </div>

          {/* Recharts Bar Chart */}
          <div style={{ width: '100%', height: '320px' }}>
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={chartData} margin={{ top: 20, right: 30, left: 0, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                <XAxis dataKey="name" tick={{ fontSize: 12, fill: '#64748b' }} />
                <YAxis tick={{ fontSize: 12, fill: '#64748b' }} domain={selectedMetricTab === 'r2' ? [0.5, 1.0] : ['auto', 'auto']} />
                <Tooltip
                  formatter={(val) => [val, selectedMetricTab.toUpperCase()]}
                  contentStyle={{ backgroundColor: 'white', borderRadius: '8px', border: '1px solid #e2e8f0' }}
                />
                <Bar
                  dataKey={selectedMetricTab === 'mae' ? 'MAE' : selectedMetricTab === 'rmse' ? 'RMSE' : 'R2'}
                  radius={[6, 6, 0, 0]}
                >
                  {chartData.map((entry) => (
                    <Cell
                      key={`cell-${entry.id}`}
                      fill={entry.id === metricsData?.best_model ? '#10b981' : '#94a3b8'}
                    />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Best Model Selection Explanation */}
        <div className="card" style={{ borderLeft: '4px solid #10b981' }}>
          <h3 style={{ fontSize: '1.1rem', fontWeight: '800', color: '#0f172a', marginBottom: '0.5rem', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
            <Award size={18} color="#10b981" />
            <span>Honest Model Selection Explanation</span>
          </h3>
          <p style={{ fontSize: '0.9rem', color: '#334155', lineHeight: '1.6' }}>
            {metricsData?.selection_reason || 'Linear Regression demonstrated the lowest MAE and highest R2 on the held-out test split, outperforming more complex tree models.'}
          </p>
          <div style={{ marginTop: '0.75rem', fontSize: '0.85rem', color: '#64748b', fontStyle: 'italic' }}>
            Note: In food delivery logistics, linear relationships often dominate distance and prep time. Complex models like Decision Trees can introduce discretization noise, while Random Forest achieved strong second-place performance (MAE: 6.77 min).
          </div>
        </div>
      </section>
    </div>
  );
}
