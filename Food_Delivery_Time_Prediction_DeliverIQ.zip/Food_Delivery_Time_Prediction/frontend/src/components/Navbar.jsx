import React, { useState } from 'react';
import { NavLink, Link } from 'react-router-dom';
import { 
  Zap, 
  MapPin, 
  BarChart3, 
  GitCompare, 
  History, 
  Compass, 
  Menu, 
  X,
  Activity
} from 'lucide-react';
import { useOrder } from '../context/OrderContext';

export default function Navbar() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const { backendStatus, lastPrediction } = useOrder();

  const navLinks = [
    { to: '/', label: 'Home', icon: Compass },
    { to: '/predict', label: 'Predict Time', icon: Zap },
    { to: '/tracking', label: 'Track Simulation', icon: MapPin },
    { to: '/compare', label: 'Compare 4 Models', icon: GitCompare },
    { to: '/analytics', label: 'Analytics', icon: BarChart3 },
    { to: '/history', label: 'History', icon: History }
  ];

  return (
    <header style={{
      backgroundColor: 'rgba(255, 255, 255, 0.95)',
      backdropFilter: 'blur(8px)',
      borderBottom: '1px solid var(--border-color)',
      position: 'sticky',
      top: 0,
      zIndex: 100
    }}>
      <div style={{
        maxWidth: '1240px',
        margin: '0 auto',
        padding: '0.85rem 1.5rem',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between'
      }}>
        {/* Logo */}
        <Link to="/" style={{ display: 'flex', alignItems: 'center', gap: '0.65rem' }}>
          <div style={{
            width: '38px',
            height: '38px',
            borderRadius: '10px',
            background: 'linear-gradient(135deg, #10b981 0%, #059669 100%)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            color: 'white',
            boxShadow: '0 2px 6px rgba(16, 185, 129, 0.35)'
          }}>
            <Zap size={22} fill="white" />
          </div>
          <div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
              <span style={{ fontSize: '1.25rem', fontWeight: '800', letterSpacing: '-0.02em', color: '#0f172a' }}>
                Deliver<span style={{ color: '#10b981' }}>IQ</span>
              </span>
              <span style={{
                fontSize: '0.65rem',
                fontWeight: '700',
                padding: '0.15rem 0.4rem',
                backgroundColor: '#ecfdf5',
                color: '#047857',
                borderRadius: '4px',
                border: '1px solid #a7f3d0'
              }}>
                ML 4-MODEL
              </span>
            </div>
            <div style={{ fontSize: '0.72rem', color: '#64748b', fontWeight: '500' }}>
              Food Delivery Time Predictor
            </div>
          </div>
        </Link>

        {/* Desktop Navigation Links */}
        <nav style={{
          display: 'none',
          alignItems: 'center',
          gap: '0.35rem',
          ...(window.innerWidth > 900 ? { display: 'flex' } : {})
        }} className="desktop-nav">
          {navLinks.map((link) => {
            const Icon = link.icon;
            return (
              <NavLink
                key={link.to}
                to={link.to}
                style={({ isActive }) => ({
                  display: 'flex',
                  alignItems: 'center',
                  gap: '0.45rem',
                  padding: '0.55rem 0.85rem',
                  borderRadius: '8px',
                  fontSize: '0.875rem',
                  fontWeight: isActive ? '700' : '500',
                  color: isActive ? '#047857' : '#475569',
                  backgroundColor: isActive ? '#ecfdf5' : 'transparent',
                  transition: 'all 0.15s ease'
                })}
              >
                <Icon size={16} />
                <span>{link.label}</span>
              </NavLink>
            );
          })}
        </nav>

        {/* Backend Status & CTA */}
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.85rem' }}>
          <div style={{
            display: 'flex',
            alignItems: 'center',
            gap: '0.4rem',
            padding: '0.3rem 0.65rem',
            borderRadius: '9999px',
            fontSize: '0.75rem',
            fontWeight: '600',
            backgroundColor: backendStatus === 'healthy' ? '#ecfdf5' : '#fef2f2',
            color: backendStatus === 'healthy' ? '#047857' : '#b91c1c',
            border: `1px solid ${backendStatus === 'healthy' ? '#a7f3d0' : '#fecaca'}`
          }}>
            <span style={{
              width: '8px',
              height: '8px',
              borderRadius: '50%',
              backgroundColor: backendStatus === 'healthy' ? '#10b981' : '#ef4444',
              display: 'inline-block'
            }} />
            <span>{backendStatus === 'healthy' ? 'Flask API Online' : 'Connecting API...'}</span>
          </div>

          <Link to="/predict" className="btn btn-primary" style={{ padding: '0.55rem 1rem', fontSize: '0.85rem' }}>
            <Zap size={15} />
            <span>Order & Predict</span>
          </Link>

          {/* Mobile hamburger button */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            style={{
              display: 'none',
              background: 'none',
              border: 'none',
              padding: '0.4rem',
              cursor: 'pointer',
              color: '#334155'
            }}
            className="mobile-toggle"
            aria-label="Toggle navigation menu"
          >
            {mobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div style={{
          backgroundColor: 'white',
          borderTop: '1px solid var(--border-color)',
          padding: '1rem 1.5rem',
          display: 'flex',
          flexDirection: 'column',
          gap: '0.5rem'
        }}>
          {navLinks.map((link) => {
            const Icon = link.icon;
            return (
              <NavLink
                key={link.to}
                to={link.to}
                onClick={() => setMobileMenuOpen(false)}
                style={({ isActive }) => ({
                  display: 'flex',
                  alignItems: 'center',
                  gap: '0.75rem',
                  padding: '0.75rem 1rem',
                  borderRadius: '8px',
                  fontSize: '0.925rem',
                  fontWeight: isActive ? '700' : '500',
                  color: isActive ? '#047857' : '#334155',
                  backgroundColor: isActive ? '#ecfdf5' : '#f8fafc'
                })}
              >
                <Icon size={18} />
                <span>{link.label}</span>
              </NavLink>
            );
          })}
        </div>
      )}

      {/* Responsive CSS for navbar */}
      <style>{`
        @media (max-width: 900px) {
          .desktop-nav { display: none !important; }
          .mobile-toggle { display: block !important; }
        }
      `}</style>
    </header>
  );
}
