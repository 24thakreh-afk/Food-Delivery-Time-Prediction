import React from 'react';
import { Link } from 'react-router-dom';
import { Zap, ShieldCheck, Cpu, Code2, Database, BookOpen } from 'lucide-react';

export default function Footer() {
  return (
    <footer style={{
      backgroundColor: '#0f172a',
      color: '#cbd5e1',
      borderTop: '1px solid #1e293b',
      padding: '3.5rem 1.5rem 2rem 1.5rem',
      marginTop: 'auto'
    }}>
      <div style={{
        maxWidth: '1240px',
        margin: '0 auto',
        display: 'grid',
        gridTemplateColumns: 'repeat(auto-fit, minmax(240px, 1fr))',
        gap: '2.5rem',
        marginBottom: '2.5rem'
      }}>
        {/* Brand & Project Summary */}
        <div>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.65rem', marginBottom: '1rem' }}>
            <div style={{
              width: '32px',
              height: '32px',
              borderRadius: '8px',
              backgroundColor: '#10b981',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              color: 'white'
            }}>
              <Zap size={18} fill="white" />
            </div>
            <span style={{ fontSize: '1.25rem', fontWeight: '800', color: 'white' }}>
              Deliver<span style={{ color: '#10b981' }}>IQ</span>
            </span>
          </div>
          <p style={{ fontSize: '0.875rem', lineHeight: '1.6', color: '#94a3b8', marginBottom: '1.25rem' }}>
            A machine learning web application predicting food delivery time in minutes using genuine real-world delivery data and comparing 4 regression algorithms.
          </p>
          <div style={{ display: 'flex', gap: '0.5rem', flexWrap: 'wrap' }}>
            <span style={{ fontSize: '0.72rem', backgroundColor: '#1e293b', padding: '0.2rem 0.5rem', borderRadius: '4px', color: '#38bdf8' }}>Scikit-Learn</span>
            <span style={{ fontSize: '0.72rem', backgroundColor: '#1e293b', padding: '0.2rem 0.5rem', borderRadius: '4px', color: '#4ade80' }}>Flask Backend</span>
            <span style={{ fontSize: '0.72rem', backgroundColor: '#1e293b', padding: '0.2rem 0.5rem', borderRadius: '4px', color: '#67e8f9' }}>React 18</span>
            <span style={{ fontSize: '0.72rem', backgroundColor: '#1e293b', padding: '0.2rem 0.5rem', borderRadius: '4px', color: '#fbcfe8' }}>SQLite</span>
          </div>
        </div>

        {/* 6 Pages Navigation */}
        <div>
          <h4 style={{ color: 'white', fontSize: '0.95rem', fontWeight: '700', marginBottom: '1rem', textTransform: 'uppercase', letterSpacing: '0.05em' }}>
            Explore Website Pages
          </h4>
          <ul style={{ listStyle: 'none', display: 'flex', flexDirection: 'column', gap: '0.65rem', fontSize: '0.875rem' }}>
            <li><Link to="/" style={{ color: '#94a3b8', transition: 'color 0.15s' }}>1. Home Landing Page</Link></li>
            <li><Link to="/predict" style={{ color: '#94a3b8', transition: 'color 0.15s' }}>2. Order Simulation & Prediction</Link></li>
            <li><Link to="/tracking" style={{ color: '#94a3b8', transition: 'color 0.15s' }}>3. Delivery Tracking Simulation</Link></li>
            <li><Link to="/compare" style={{ color: '#94a3b8', transition: 'color 0.15s' }}>4. Compare All 4 ML Models</Link></li>
            <li><Link to="/analytics" style={{ color: '#94a3b8', transition: 'color 0.15s' }}>5. Model Insights & Analytics</Link></li>
            <li><Link to="/history" style={{ color: '#94a3b8', transition: 'color 0.15s' }}>6. Prediction History</Link></li>
          </ul>
        </div>

        {/* Machine Learning Models */}
        <div>
          <h4 style={{ color: 'white', fontSize: '0.95rem', fontWeight: '700', marginBottom: '1rem', textTransform: 'uppercase', letterSpacing: '0.05em' }}>
            Evaluated Regressors
          </h4>
          <ul style={{ listStyle: 'none', display: 'flex', flexDirection: 'column', gap: '0.65rem', fontSize: '0.875rem', color: '#94a3b8' }}>
            <li style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
              <span style={{ width: '6px', height: '6px', borderRadius: '50%', backgroundColor: '#10b981' }} />
              Linear Regression (MAE: 6.06 min)
            </li>
            <li style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
              <span style={{ width: '6px', height: '6px', borderRadius: '50%', backgroundColor: '#38bdf8' }} />
              Random Forest Regressor (MAE: 6.77 min)
            </li>
            <li style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
              <span style={{ width: '6px', height: '6px', borderRadius: '50%', backgroundColor: '#a855f7' }} />
              KNN Regressor (MAE: 8.30 min)
            </li>
            <li style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
              <span style={{ width: '6px', height: '6px', borderRadius: '50%', backgroundColor: '#f97316' }} />
              Decision Tree Regressor (MAE: 8.51 min)
            </li>
          </ul>
        </div>

        {/* Academic / Faculty Presentation Note */}
        <div>
          <h4 style={{ color: 'white', fontSize: '0.95rem', fontWeight: '700', marginBottom: '1rem', textTransform: 'uppercase', letterSpacing: '0.05em' }}>
            Academic Evaluation
          </h4>
          <div style={{
            backgroundColor: '#1e293b',
            padding: '1rem',
            borderRadius: '8px',
            border: '1px solid #334155',
            fontSize: '0.825rem',
            lineHeight: '1.5',
            color: '#94a3b8'
          }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem', color: '#38bdf8', fontWeight: '600', marginBottom: '0.4rem' }}>
              <BookOpen size={14} />
              <span>Project Defense Highlights</span>
            </div>
            Trained on 1,000 real deliveries across 7 input features with strict 80-20 train-test separation, pipeline-based scaling, one-hot encoding, and persistent SQLite history.
          </div>
        </div>
      </div>

      <div style={{
        maxWidth: '1240px',
        margin: '0 auto',
        paddingTop: '1.5rem',
        borderTop: '1px solid #1e293b',
        display: 'flex',
        flexWrap: 'wrap',
        alignItems: 'center',
        justifyContent: 'space-between',
        fontSize: '0.8rem',
        color: '#64748b',
        gap: '1rem'
      }}>
        <div>
          © 2026 DeliverIQ — Food Delivery Time Prediction Project. All evaluation metrics calculated on held-out test data.
        </div>
        <div style={{ display: 'flex', gap: '1.5rem' }}>
          <span>Dataset: Food_delivery_Times.csv</span>
          <span>Evaluation: MAE • MSE • RMSE • R²</span>
        </div>
      </div>
    </footer>
  );
}
