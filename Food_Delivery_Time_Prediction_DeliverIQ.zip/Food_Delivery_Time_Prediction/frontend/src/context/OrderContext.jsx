import React, { createContext, useContext, useState, useEffect } from 'react';

const OrderContext = createContext();

export const SAMPLE_RESTAURANTS = [
  {
    id: 'rest-1',
    name: 'Artisan Woodfire Pizza & Co.',
    cuisine: 'Italian • Stone Oven Pizzas',
    rating: 4.8,
    reviews: 320,
    prepTime: 18,
    distanceKm: 4.5,
    tag: 'Bestseller',
    image: 'https://images.unsplash.com/photo-1513104890138-7c749659a591?w=500&auto=format&fit=crop&q=60',
    menu: [
      { id: 'm1', name: 'Margherita Fresca with Basil', price: 14.50, desc: 'San Marzano tomatoes, fresh mozzarella, extra virgin olive oil' },
      { id: 'm2', name: 'Truffle Mushroom Pizza', price: 18.00, desc: 'Wild forest mushrooms, buffalo mozzarella, white truffle oil' },
      { id: 'm3', name: 'Garlic Parmesan Focaccia', price: 6.50, desc: 'Rosemary infused flatbread with roasted garlic dip' }
    ]
  },
  {
    id: 'rest-2',
    name: 'Tokyo Ramen & Bento Bar',
    cuisine: 'Japanese • Handcrafted Noodles',
    rating: 4.9,
    reviews: 512,
    prepTime: 14,
    distanceKm: 3.2,
    tag: 'Top Rated',
    image: 'https://images.unsplash.com/photo-1569718212165-3a8278d5f624?w=500&auto=format&fit=crop&q=60',
    menu: [
      { id: 'm4', name: 'Tonkotsu Chashu Ramen', price: 16.00, desc: 'Rich 16-hour pork broth, nitamago egg, tender pork belly' },
      { id: 'm5', name: 'Crispy Gyoza Dumplings (6 pcs)', price: 7.50, desc: 'Pan-seared chicken dumplings with sesame ponzu dip' },
      { id: 'm6', name: 'Salmon Teriyaki Bento', price: 17.50, desc: 'Glazed Atlantic salmon, jasmine rice, edamame and wakame' }
    ]
  },
  {
    id: 'rest-3',
    name: 'Smash & Sizzle Craft Burgers',
    cuisine: 'American • Gourmet Burgers & Shakes',
    rating: 4.7,
    reviews: 280,
    prepTime: 12,
    distanceKm: 6.8,
    tag: 'Trending',
    image: 'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=500&auto=format&fit=crop&q=60',
    menu: [
      { id: 'm7', name: 'Double Bacon Smash Burger', price: 15.00, desc: 'Aged cheddar, caramelized onions, smoked bacon, secret sauce' },
      { id: 'm8', name: 'Truffle Parmesan Fries', price: 5.50, desc: 'Crispy skin-on fries with garlic aioli and shaved parm' },
      { id: 'm9', name: 'Salted Caramel Milkshake', price: 6.00, desc: 'Hand-spun Madagascar vanilla bean shake with sea salt caramel' }
    ]
  },
  {
    id: 'rest-4',
    name: 'Green Harvest Organic Bowls',
    cuisine: 'Healthy • Bowls & Cold-Pressed Juices',
    rating: 4.8,
    reviews: 195,
    prepTime: 10,
    distanceKm: 2.1,
    tag: 'Super Healthy',
    image: 'https://images.unsplash.com/photo-1540420773420-3366772f4999?w=500&auto=format&fit=crop&q=60',
    menu: [
      { id: 'm10', name: 'Superfood Quinoa Buddha Bowl', price: 13.50, desc: 'Avocado, roasted chickpeas, purple cabbage, tahini lemon dressing' },
      { id: 'm11', name: 'Wild Acai Berry Bowl', price: 11.00, desc: 'Organic acai, chia seeds, sliced bananas, almond butter drizzle' },
      { id: 'm12', name: 'Immunity Citrus Cold Press (350ml)', price: 5.50, desc: 'Orange, turmeric, ginger, cayenne and raw honey' }
    ]
  }
];

export const OrderProvider = ({ children }) => {
  const [selectedRestaurant, setSelectedRestaurant] = useState(SAMPLE_RESTAURANTS[0]);
  const [cartItems, setCartItems] = useState([
    { ...SAMPLE_RESTAURANTS[0].menu[0], qty: 1 },
    { ...SAMPLE_RESTAURANTS[0].menu[2], qty: 1 }
  ]);

  // Actual Machine Learning Input Features
  const [features, setFeatures] = useState({
    distance_km: 4.5,
    weather: 'Clear',
    traffic_level: 'Medium',
    time_of_day: 'Evening',
    vehicle_type: 'Bike',
    preparation_time_min: 18,
    courier_experience_yrs: 4
  });

  // Active prediction results from backend
  const [lastPrediction, setLastPrediction] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const [backendStatus, setBackendStatus] = useState('checking'); // 'healthy' | 'error' | 'checking'

  // Check backend health on initial load
  useEffect(() => {
    fetch('/api/health')
      .then(res => res.json())
      .then(data => {
        if (data.status === 'healthy') setBackendStatus('healthy');
        else setBackendStatus('error');
      })
      .catch(() => setBackendStatus('error'));
  }, []);

  const addToCart = (item) => {
    setCartItems(prev => {
      const existing = prev.find(i => i.id === item.id);
      if (existing) {
        return prev.map(i => i.id === item.id ? { ...i, qty: i.qty + 1 } : i);
      }
      return [...prev, { ...item, qty: 1 }];
    });
  };

  const removeFromCart = (itemId) => {
    setCartItems(prev => {
      const existing = prev.find(i => i.id === itemId);
      if (existing && existing.qty > 1) {
        return prev.map(i => i.id === itemId ? { ...i, qty: i.qty - 1 } : i);
      }
      return prev.filter(i => i.id !== itemId);
    });
  };

  const updateFeature = (key, value) => {
    setFeatures(prev => ({
      ...prev,
      [key]: value
    }));
  };

  return (
    <OrderContext.Provider value={{
      selectedRestaurant,
      setSelectedRestaurant,
      cartItems,
      addToCart,
      removeFromCart,
      features,
      setFeatures,
      updateFeature,
      lastPrediction,
      setLastPrediction,
      isLoading,
      setIsLoading,
      backendStatus
    }}>
      {children}
    </OrderContext.Provider>
  );
};

export const useOrder = () => useContext(OrderContext);
