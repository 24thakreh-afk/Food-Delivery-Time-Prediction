import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Navbar from './components/Navbar';
import Footer from './components/Footer';
import Home from './pages/Home';
import Prediction from './pages/Prediction';
import Tracking from './pages/Tracking';
import ModelComparison from './pages/ModelComparison';
import Analytics from './pages/Analytics';
import PredictionHistory from './pages/PredictionHistory';
import NotFound from './pages/NotFound';
import { OrderProvider } from './context/OrderContext';

export default function App() {
  return (
    <OrderProvider>
      <Router>
        <div className="app-container">
          <Navbar />
          <main className="main-content">
            <Routes>
              <Route path="/" element={<Home />} />
              <Route path="/predict" element={<Prediction />} />
              <Route path="/tracking" element={<Tracking />} />
              <Route path="/compare" element={<ModelComparison />} />
              <Route path="/analytics" element={<Analytics />} />
              <Route path="/history" element={<PredictionHistory />} />
              <Route path="*" element={<NotFound />} />
            </Routes>
          </main>
          <Footer />
        </div>
      </Router>
    </OrderProvider>
  );
}
