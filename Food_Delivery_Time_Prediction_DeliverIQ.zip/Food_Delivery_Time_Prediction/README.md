# DeliverIQ — Food Delivery Time Prediction Using Machine Learning

> A complete full-stack machine learning web application that predicts food delivery time in minutes using real-world data and evaluates four regression models: **Linear Regression**, **Decision Tree Regressor**, **K-Nearest Neighbors (KNN)**, and **Random Forest Regressor**.

Built with a **React.js** frontend and a **Python Flask** backend.

---

## 📋 Table of Contents
1. [Project Overview & Key Highlights](#-project-overview--key-highlights)
2. [Project Architecture & File Structure](#-project-architecture--file-structure)
3. [The Four Machine Learning Models](#-the-four-machine-learning-models)
4. [Dataset Inspection & Preprocessing](#-dataset-inspection--preprocessing)
5. [Model Evaluation Metrics Explained](#-model-evaluation-metrics-explained)
6. [The Six Website Pages](#-the-six-website-pages)
7. [Beginner Quickstart Guide (Windows PowerShell)](#-beginner-quickstart-guide-windows-powershell)
8. [How Frontend Communicates with Backend](#-how-frontend-communicates-with-backend)
9. [Troubleshooting Common Issues](#-troubleshooting-common-issues)
10. [College Faculty & Project Defense Q&A Guide](#-college-faculty--project-defense-qa-guide)

---

## 🌟 Project Overview & Key Highlights

- **Predicts delivery time in minutes** based on real factors: distance, weather condition, traffic congestion, time of day, vehicle type, kitchen preparation time, and courier experience.
- **Trained on genuine data**: 1,000 observations from `Food_delivery_Times.csv` with 80/20 train-test split.
- **Evaluates 4 exact regression models**:
  1. Linear Regression (Top Performer: **MAE 6.06 min**, **R² 0.8212**)
  2. Random Forest Regressor (**MAE 6.77 min**, **R² 0.7956**)
  3. K-Nearest Neighbors (KNN) (**MAE 8.30 min**, **R² 0.7232**)
  4. Decision Tree Regressor (**MAE 8.51 min**, **R² 0.7017**)
- **No hardcoded numbers or rankings**: All metrics, predictions, and feature importance values are dynamically computed and retrieved from scikit-learn pipelines.
- **Six integrated pages**: Home, Prediction, Tracking Simulation, 4-Model Comparison, Analytics, and Prediction History with SQLite.

---

## 📁 Project Architecture & File Structure

```text
Food_Delivery_Time_Prediction/
│
├── data/
│   └── Food_delivery_Times.csv          # The real dataset (1000 rows, 9 columns)
│
├── backend/
│   ├── app.py                           # Flask REST API server & SQLite database
│   ├── train_model.py                   # Model training, preprocessing & evaluation
│   ├── requirements.txt                 # Python dependencies
│   ├── prediction_history.db            # SQLite persistent history database
│   └── models/
│       ├── linear_regression.joblib     # Saved scikit-learn pipeline
│       ├── decision_tree.joblib         # Saved scikit-learn pipeline
│       ├── knn.joblib                   # Saved scikit-learn pipeline
│       ├── random_forest.joblib         # Saved scikit-learn pipeline
│       ├── metrics.json                 # Test metrics (MAE, MSE, RMSE, R2, feature weights)
│       └── dataset_summary.json         # Summary statistics of the dataset
│
├── frontend/
│   ├── src/
│   │   ├── components/
│   │   │   ├── Navbar.jsx               # Navigation bar with active route highlight & API status
│   │   │   └── Footer.jsx               # Project summary, model list, academic notes
│   │   ├── context/
│   │   │   └── OrderContext.jsx         # Shared React state (cart, features, live predictions)
│   │   ├── pages/
│   │   │   ├── Home.jsx                 # Page 1: Landing page with featured kitchens & workflow
│   │   │   ├── Prediction.jsx           # Page 2: Food cart + ML input form + 4-model results
│   │   │   ├── Tracking.jsx             # Page 3: OpenStreetMap route & 3-stage delivery simulation
│   │   │   ├── ModelComparison.jsx      # Page 4: Order comparison cards + Recharts metric charts
│   │   │   ├── Analytics.jsx            # Page 5: Feature importance + dataset summary + error curves
│   │   │   ├── PredictionHistory.jsx    # Page 6: SQLite records table + detail modal + clear all
│   │   │   └── NotFound.jsx             # 404 route fallback
│   │   ├── styles/
│   │   │   └── index.css                # Global design system (colors, typography, cards, badges)
│   │   ├── App.jsx                      # React Router configuration
│   │   └── main.jsx                     # Application entry point
│   ├── dist/                            # Production build (served directly by Flask or Vite)
│   ├── public/
│   ├── index.html                       # HTML5 template with Leaflet & Google Fonts
│   ├── package.json                     # NPM dependencies and scripts
│   └── vite.config.js                   # Vite configuration with API proxy to port 5000
│
├── tests/
│   ├── test_api.py                      # Flask endpoint unit tests
│   └── test_full_suite.py               # Complete 8-point automated integration test suite
│
└── README.md                            # Complete documentation & defense guide
```

---

## 🤖 The Four Machine Learning Models

| Model | Algorithm Family | Strengths in Delivery Prediction | Test Set MAE | Test Set R² |
| :--- | :--- | :--- | :--- | :--- |
| **Linear Regression** | Parametric Linear | Models proportional transit distance and prep time cleanly with minimal variance. | **±6.06 min** (Winner) | **0.8212** |
| **Random Forest Regressor** | Bagging Ensemble | Averages 100 decorrelated decision trees; handles non-linear traffic and weather interactions well. | **±6.77 min** | **0.7956** |
| **K-Nearest Neighbors (KNN)** | Instance-Based Metric | Uses standardized Euclidean distance to find the 7 most similar historical deliveries. | **±8.30 min** | **0.7232** |
| **Decision Tree Regressor** | Recursive Partitioning | Builds orthogonal threshold rules; interpretable but sensitive to step-boundary variance. | **±8.51 min** | **0.7017** |

> **Academic Note**: Linear Regression outperformed tree models on this dataset because delivery time has strong linear correlation with distance and kitchen prep time, whereas decision trees introduce step-function quantization.

---

## 📊 Dataset Inspection & Preprocessing

The real dataset `data/Food_delivery_Times.csv` contains:
- **1,000 rows** and **9 columns**.
- **Target Variable**: `Delivery_Time_min` (Range: 8 to 153 mins, Mean: 56.7 mins).
- **Features**:
  1. `Distance_km` (Numerical, 0.59 to 19.99 km)
  2. `Preparation_Time_min` (Numerical, 5 to 29 mins)
  3. `Courier_Experience_yrs` (Numerical, 0 to 9 years, 30 missing values)
  4. `Weather` (Categorical: Clear, Foggy, Rainy, Snowy, Windy, 30 missing values)
  5. `Traffic_Level` (Categorical: Low, Medium, High, 30 missing values)
  6. `Time_of_Day` (Categorical: Morning, Afternoon, Evening, Night, 30 missing values)
  7. `Vehicle_Type` (Categorical: Bike, Scooter, Car, 0 missing values)
  8. `Order_ID` (Identifier, dropped to avoid arbitrary feature noise)

### Preprocessing Pipeline:
- **Missing Value Imputation**: Numerical missing values are imputed using `SimpleImputer(strategy='median')`; categorical missing values are imputed using `SimpleImputer(strategy='most_frequent')`.
- **Feature Scaling**: Numerical features (`Distance_km`, `Preparation_Time_min`, `Courier_Experience_yrs`) are scaled with `StandardScaler` to zero mean and unit variance.
- **Categorical Encoding**: Categorical features are converted into dummy variables using `OneHotEncoder(handle_unknown='ignore', sparse_output=False)`.
- **Preventing Data Leakage**: All preprocessors are fitted strictly on the 800 training samples (`X_train`) and applied downstream during inference.

---

## 📈 Model Evaluation Metrics Explained

1. **Mean Absolute Error (MAE)** *(Lower is Better)*:
   - Average difference in minutes between actual delivery time and predicted delivery time:
     $$\text{MAE} = \frac{1}{n} \sum_{i=1}^{n} |y_i - \hat{y}_i|$$
   - In our project: Linear Regression has an MAE of 6.06 min, meaning predictions are off by only ~6 minutes on average.
2. **Mean Squared Error (MSE)** *(Lower is Better)*:
   - Average of the squared errors:
     $$\text{MSE} = \frac{1}{n} \sum_{i=1}^{n} (y_i - \hat{y}_i)^2$$
3. **Root Mean Squared Error (RMSE)** *(Lower is Better)*:
   - The square root of MSE, bringing the error back to interpretable minutes:
     $$\text{RMSE} = \sqrt{\text{MSE}}$$
   - Penalizes large outlier errors more heavily than MAE.
4. **$R^2$ Score (Coefficient of Determination)** *(Higher is Better, Max 1.0)*:
   - Measures how much of the variance in delivery time is explained by the input features:
     $$R^2 = 1 - \frac{\sum (y_i - \hat{y}_i)^2}{\sum (y_i - \bar{y})^2}$$
   - An $R^2$ of 0.8212 means 82.1% of delivery time variations are accounted for by our features.

---

## 💻 The Six Website Pages

1. **Page 1: Home (`/`)**:
   - Modern landing page with a hero banner, key dataset metrics, curated restaurant cards, a 3-step workflow explanation, and an introduction to all four ML algorithms.
2. **Page 2: Order Simulation & Prediction (`/predict`)**:
   - Interactive food menu cart paired with an input form containing the exact 7 dataset features. Submits inputs to Flask, runs all 4 models, displays the best model's ETA, and compares all 4 outputs side by side.
3. **Page 3: Delivery Tracking Simulation (`/tracking`)**:
   - Interactive OpenStreetMap (Leaflet) with simulated route waypoints, moving courier marker, progress bar, play/pause and speed controls (1x, 2x, 5x), and 3 labeled stages (*Order Preparation* → *Out for Delivery* → *Delivered*).
4. **Page 4: Compare All 4 Models (`/compare`)**:
   - Compares live predictions for the active order across models. Displays an overall benchmark table and interactive Recharts bar charts for MAE, RMSE, and $R^2$ with clear metric definitions.
5. **Page 5: Model Insights & Analytics (`/analytics`)**:
   - In-depth look at the data: Random Forest feature importances (Distance: 74%, Prep time: 14%), actual vs. predicted curves, missing value reports, and logistics takeaways.
6. **Page 6: Prediction History (`/history`)**:
   - SQLite-backed history table storing past predictions, model outputs, timestamps, and input details. Allows viewing details, deleting individual records, or clearing the entire database.

---

## 🚀 Beginner Quickstart Guide (Windows PowerShell)

Follow these steps to run the application locally on Windows.

### Step 1: Clone or Navigate to the Project Folder
Open Windows PowerShell and navigate to the project directory:
```powershell
cd "c:\Users\Harshita\OneDrive\Desktop\ドキュメント\ML_PROJECT"
```

### Step 2: Ensure Node.js is in your PATH
If Node.js is installed locally in AppData or Program Files:
```powershell
$env:Path = "C:\Users\Harshita\AppData\Local\Programs\nodejs;$env:Path"
node -v
npm -v
```

### Step 3: Train and Save the ML Models
Run the training script once. This inspects `data/Food_delivery_Times.csv`, trains all 4 regression models, calculates test-set metrics, and saves the `.joblib` pipelines:
```powershell
$env:PYTHONIOENCODING="utf-8"
python backend/train_model.py
```

### Step 4: Start the Flask Backend Server
In Terminal 1, start the Flask backend:
```powershell
$env:PYTHONIOENCODING="utf-8"
python backend/app.py
```
> The backend will start on **`http://localhost:5000`** with all 4 models and the SQLite database ready.

### Step 5: Start the React Frontend Server
Open a **second PowerShell terminal** and run:
```powershell
cd "c:\Users\Harshita\OneDrive\Desktop\ドキュメント\ML_PROJECT\frontend"
$env:Path = "C:\Users\Harshita\AppData\Local\Programs\nodejs;$env:Path"
npm run dev
```
> The frontend dev server will launch at **`http://localhost:5173`**.

### Step 6: Open the Website in Your Browser
Visit:
👉 **`http://localhost:5173`**

*(Alternatively, because the frontend production build has already been compiled into `frontend/dist/`, navigating directly to `http://localhost:5000` will also display the complete application!)*

---

## 🔄 How Frontend Communicates with Backend

1. **Vite Proxy (`vite.config.js`)**: Any request sent to `/api/*` from React is automatically proxied to `http://127.0.0.1:5000`.
2. **CORS Support**: `flask-cors` is enabled on the backend to allow cross-origin requests during local development.
3. **Data Flow**:
   - User submits form on Page 2 (`Prediction.jsx`).
   - React sends a `POST` request with JSON payload to `/api/predict`.
   - Flask validates the features, runs each saved model pipeline, computes the ETA, and records the prediction into SQLite (`prediction_history.db`).
   - Flask returns a JSON response containing all four predictions and the best model.
   - React stores the response in `OrderContext.jsx`, instantly updating the Prediction, Tracking, and Comparison views.

---

## 🛠️ Troubleshooting Common Issues

| Issue | Likely Cause | Solution |
| :--- | :--- | :--- |
| `UnicodeEncodeError: 'charmap' codec can't encode...` | Windows console with non-ASCII directory paths. | Run `$env:PYTHONIOENCODING="utf-8"` before launching Python. |
| `'node' is not recognized` | Node.js directory is not added to the current session's PATH. | Run `$env:Path = "C:\Users\Harshita\AppData\Local\Programs\nodejs;$env:Path"`. |
| Port 5000 already in use | Previous Flask process still running in the background. | In PowerShell run: `Get-Process python \| Stop-Process -Force`. |
| Model files not found error | `train_model.py` has not been executed yet. | Run `python backend/train_model.py` to regenerate the model artifacts. |

---

## 🎓 College Faculty & Project Defense Q&A Guide

Prepare for your presentation and viva with these concise answers:

1. **Q: Why are there four models instead of just one?**
   - *A: Comparing multiple regression families (linear, tree-based, distance-based, and ensemble) allows us to evaluate which inductive bias best fits food delivery dynamics, providing a rigorous academic comparison rather than guessing.*
2. **Q: Why did Linear Regression win over Random Forest?**
   - *A: Real-world transit time is primarily a continuous linear function of travel distance ($R^2 \approx 0.82$) and prep time. Random Forest performed well (MAE 6.77 min), but Linear Regression achieved the lowest MAE (6.06 min) without step-function discretization.*
3. **Q: How did you prevent data leakage?**
   - *A: We performed an 80/20 train-test split before fitting any preprocessors. The `StandardScaler`, `SimpleImputer`, and `OneHotEncoder` were fitted exclusively on `X_train`, ensuring `X_test` remained completely unseen.*
4. **Q: Why is feature scaling necessary?**
   - *A: Distance (0.5–20 km) and prep time (5–30 mins) have different numerical magnitudes. Distance-based algorithms like KNN would be overwhelmed by larger-scale features without `StandardScaler`.*
5. **Q: How does Random Forest calculate feature importance?**
   - *A: Scikit-learn measures the Mean Decrease in Impurity (Gini/Variance reduction) brought by each feature split across all 100 decision trees. Distance accounted for ~74% of the importance, confirming it is the primary physical constraint on delivery speed.*
