import os
import sys
import json
import unittest

if sys.stdout is not None:
    sys.stdout.reconfigure(encoding='utf-8', errors='replace')

BASE_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
sys.path.insert(0, BASE_DIR)

from backend.app import app

class TestDeliverIQFullSuite(unittest.TestCase):
    def setUp(self):
        self.client = app.test_client()

    def test_01_dataset_exists(self):
        csv_path = os.path.join(BASE_DIR, 'data', 'Food_delivery_Times.csv')
        self.assertTrue(os.path.exists(csv_path), "Food_delivery_Times.csv must exist in data/")

    def test_02_all_four_models_saved(self):
        models = ['linear_regression.joblib', 'decision_tree.joblib', 'knn.joblib', 'random_forest.joblib', 'metrics.json', 'dataset_summary.json']
        for m in models:
            path = os.path.join(BASE_DIR, 'backend', 'models', m)
            self.assertTrue(os.path.exists(path), f"Expected model asset {m} to exist")

    def test_03_health_endpoint(self):
        res = self.client.get('/api/health')
        self.assertEqual(res.status_code, 200)
        data = res.get_json()
        self.assertEqual(len(data['models_loaded']), 4)

    def test_04_metrics_endpoint(self):
        res = self.client.get('/api/models/metrics')
        self.assertEqual(res.status_code, 200)
        data = res.get_json()
        self.assertIn('linear_regression', data['models'])
        self.assertIn('decision_tree', data['models'])
        self.assertIn('knn', data['models'])
        self.assertIn('random_forest', data['models'])
        self.assertIn('best_model', data)
        # Check metric values
        for key, m in data['models'].items():
            self.assertGreater(m['mae'], 0)
            self.assertGreater(m['rmse'], 0)
            self.assertGreater(m['r2'], 0)

    def test_05_predict_all_four_models(self):
        payload = {
            'distance_km': 8.2,
            'weather': 'Clear',
            'traffic_level': 'Medium',
            'time_of_day': 'Evening',
            'vehicle_type': 'Scooter',
            'preparation_time_min': 15,
            'courier_experience_yrs': 5,
            'restaurant_name': 'Sushi Express',
            'items_summary': '1x Bento Box'
        }
        res = self.client.post('/api/predict', json=payload)
        self.assertEqual(res.status_code, 200)
        data = res.get_json()
        self.assertTrue(data['success'])
        self.assertIn('predictions', data)
        self.assertIn('linear_regression', data['predictions'])
        self.assertIn('decision_tree', data['predictions'])
        self.assertIn('knn', data['predictions'])
        self.assertIn('random_forest', data['predictions'])
        self.assertIn('best_model', data)
        self.assertIn('estimated_eta', data)

    def test_06_predict_validation_errors(self):
        # Negative distance
        res = self.client.post('/api/predict', json={'distance_km': -5})
        self.assertEqual(res.status_code, 400)
        # Missing payload
        res = self.client.post('/api/predict', data="not json", content_type="application/json")
        self.assertEqual(res.status_code, 400)

    def test_07_history_crud(self):
        res = self.client.get('/api/history')
        self.assertEqual(res.status_code, 200)
        history = res.get_json()
        self.assertIsInstance(history, list)

    def test_08_frontend_dist_built(self):
        dist_index = os.path.join(BASE_DIR, 'frontend', 'dist', 'index.html')
        self.assertTrue(os.path.exists(dist_index), "Frontend must be compiled and ready in frontend/dist/")

if __name__ == '__main__':
    unittest.main()
