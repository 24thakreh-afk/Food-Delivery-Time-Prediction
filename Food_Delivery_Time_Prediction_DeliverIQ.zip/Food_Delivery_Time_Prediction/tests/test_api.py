import os
import sys
import json

if sys.stdout is not None:
    sys.stdout.reconfigure(encoding='utf-8', errors='replace')

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from backend.app import app

client = app.test_client()

print('--- Testing /api/health ---')
res = client.get('/api/health')
print('Health status:', res.status_code, res.get_json())

print('\n--- Testing /api/models/metrics ---')
res = client.get('/api/models/metrics')
print('Metrics status:', res.status_code)
metrics = res.get_json()
print('Best model:', metrics['best_model'])
for k, m in metrics['models'].items():
    print(f" {m['name']}: MAE={m['mae']}, RMSE={m['rmse']}, R2={m['r2']}")

print('\n--- Testing /api/predict ---')
payload = {
    'distance_km': 6.5,
    'weather': 'Rainy',
    'traffic_level': 'High',
    'time_of_day': 'Evening',
    'vehicle_type': 'Bike',
    'preparation_time_min': 15,
    'courier_experience_yrs': 3,
    'restaurant_name': 'Burger Bistro',
    'items_summary': '1x Classic Burger, 1x Fries'
}
res = client.post('/api/predict', json=payload)
print('Predict status:', res.status_code)
pred_data = res.get_json()
print('Best model:', pred_data['best_model'])
print('ETA:', pred_data['estimated_eta'])
print('All model predictions:')
for k, p in pred_data['predictions'].items():
    print(f" {p['name']}: {p['time_min']} mins")

print('\n--- Testing /api/history ---')
res = client.get('/api/history')
print('History status:', res.status_code, 'Record count:', len(res.get_json()))
