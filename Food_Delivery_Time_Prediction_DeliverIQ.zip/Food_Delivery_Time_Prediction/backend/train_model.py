import os
import sys
import json
import joblib
import numpy as np
import pandas as pd

# Ensure UTF-8 output on Windows consoles with international paths
if sys.stdout is not None:
    sys.stdout.reconfigure(encoding='utf-8', errors='replace')
if sys.stderr is not None:
    sys.stderr.reconfigure(encoding='utf-8', errors='replace')
from sklearn.model_selection import train_test_split
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.linear_model import LinearRegression
from sklearn.tree import DecisionTreeRegressor
from sklearn.neighbors import KNeighborsRegressor
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score

def train_and_evaluate():
    # Resolve directories
    base_dir = os.path.dirname(os.path.abspath(__file__))
    project_dir = os.path.dirname(base_dir)
    data_path = os.path.join(project_dir, 'data', 'Food_delivery_Times.csv')
    models_dir = os.path.join(base_dir, 'models')
    os.makedirs(models_dir, exist_ok=True)

    print(f"Loading data from: {data_path}")
    df = pd.read_csv(data_path)
    print(f"Dataset loaded: {df.shape[0]} rows, {df.shape[1]} columns")

    # Features and Target
    target_col = 'Delivery_Time_min'
    id_col = 'Order_ID'
    
    # Drop identifier column
    features_df = df.drop(columns=[id_col, target_col])
    target_series = df[target_col]

    num_cols = ['Distance_km', 'Preparation_Time_min', 'Courier_Experience_yrs']
    cat_cols = ['Weather', 'Traffic_Level', 'Time_of_Day', 'Vehicle_Type']

    # Dataset Summary stats for Analytics Page
    summary_data = {
        'total_rows': int(df.shape[0]),
        'total_columns': int(df.shape[1]),
        'feature_names': list(features_df.columns),
        'numerical_features': num_cols,
        'categorical_features': cat_cols,
        'target_variable': target_col,
        'missing_values': {col: int(df[col].isnull().sum()) for col in df.columns},
        'categorical_options': {
            'Weather': sorted([str(x) for x in df['Weather'].dropna().unique()]),
            'Traffic_Level': sorted([str(x) for x in df['Traffic_Level'].dropna().unique()]),
            'Time_of_Day': sorted([str(x) for x in df['Time_of_Day'].dropna().unique()]),
            'Vehicle_Type': sorted([str(x) for x in df['Vehicle_Type'].dropna().unique()]),
        },
        'numerical_ranges': {
            'Distance_km': {'min': float(df['Distance_km'].min()), 'max': float(df['Distance_km'].max()), 'mean': float(df['Distance_km'].mean())},
            'Preparation_Time_min': {'min': float(df['Preparation_Time_min'].min()), 'max': float(df['Preparation_Time_min'].max()), 'mean': float(df['Preparation_Time_min'].mean())},
            'Courier_Experience_yrs': {'min': float(df['Courier_Experience_yrs'].min()), 'max': float(df['Courier_Experience_yrs'].max()), 'mean': float(df['Courier_Experience_yrs'].mean())},
            'Delivery_Time_min': {'min': float(df['Delivery_Time_min'].min()), 'max': float(df['Delivery_Time_min'].max()), 'mean': float(df['Delivery_Time_min'].mean())}
        }
    }

    with open(os.path.join(models_dir, 'dataset_summary.json'), 'w', encoding='utf-8') as f:
        json.dump(summary_data, f, indent=2)

    # Held-out train-test split (80% train, 20% test, fixed random_state for reproducibility)
    X_train, X_test, y_train, y_test = train_test_split(
        features_df, target_series, test_size=0.20, random_state=42
    )
    print(f"Training split: {X_train.shape[0]} samples, Testing split: {X_test.shape[0]} samples")

    # Unified Preprocessing Pipeline (prevent data leakage by fitting ONLY on train)
    preprocessor = ColumnTransformer(
        transformers=[
            ('num', Pipeline([
                ('imputer', SimpleImputer(strategy='median')),
                ('scaler', StandardScaler())
            ]), num_cols),
            ('cat', Pipeline([
                ('imputer', SimpleImputer(strategy='most_frequent')),
                ('encoder', OneHotEncoder(handle_unknown='ignore', sparse_output=False))
            ]), cat_cols)
        ]
    )

    # 4 Exact Regression Models Required
    models_def = {
        'linear_regression': {
            'name': 'Linear Regression',
            'regressor': LinearRegression()
        },
        'decision_tree': {
            'name': 'Decision Tree Regressor',
            'regressor': DecisionTreeRegressor(max_depth=6, min_samples_leaf=4, random_state=42)
        },
        'knn': {
            'name': 'K-Nearest Neighbors (KNN) Regressor',
            'regressor': KNeighborsRegressor(n_neighbors=7, weights='distance')
        },
        'random_forest': {
            'name': 'Random Forest Regressor',
            'regressor': RandomForestRegressor(n_estimators=100, max_depth=8, min_samples_leaf=3, random_state=42)
        }
    }

    metrics_results = {}
    test_predictions_samples = []

    best_model_key = None
    lowest_mae = float('inf')

    # Fit each pipeline and evaluate
    for key, item in models_def.items():
        print(f"\n--- Training {item['name']} ---")
        pipeline = Pipeline([
            ('preprocessor', preprocessor),
            ('regressor', item['regressor'])
        ])

        pipeline.fit(X_train, y_train)
        y_pred = pipeline.predict(X_test)

        mae = float(mean_absolute_error(y_test, y_pred))
        mse = float(mean_squared_error(y_test, y_pred))
        rmse = float(np.sqrt(mse))
        r2 = float(r2_score(y_test, y_pred))

        # Save model pipeline
        model_filepath = os.path.join(models_dir, f"{key}.joblib")
        joblib.dump(pipeline, model_filepath)
        print(f"Saved {key} model to {model_filepath}")
        print(f"MAE: {mae:.3f} | MSE: {mse:.3f} | RMSE: {rmse:.3f} | R2: {r2:.4f}")

        metrics_results[key] = {
            'id': key,
            'name': item['name'],
            'mae': round(mae, 2),
            'mse': round(mse, 2),
            'rmse': round(rmse, 2),
            'r2': round(r2, 4)
        }

        # Track the best model based on MAE/RMSE
        if mae < lowest_mae:
            lowest_mae = mae
            best_model_key = key

    # Extract transformed feature names from fitted preprocessor
    fitted_preprocessor = joblib.load(os.path.join(models_dir, 'random_forest.joblib')).named_steps['preprocessor']
    cat_feature_names = fitted_preprocessor.named_transformers_['cat'].named_steps['encoder'].get_feature_names_out(cat_cols)
    all_feature_names = list(num_cols) + list(cat_feature_names)

    # Feature Importance from Random Forest
    rf_pipeline = joblib.load(os.path.join(models_dir, 'random_forest.joblib'))
    rf_importances = rf_pipeline.named_steps['regressor'].feature_importances_
    importance_list = [
        {'feature': feat, 'importance': round(float(imp) * 100, 2)}
        for feat, imp in zip(all_feature_names, rf_importances)
    ]
    importance_list = sorted(importance_list, key=lambda x: x['importance'], reverse=True)

    # Sample actual vs predicted points for analytics charts (first 40 test samples)
    rf_preds = rf_pipeline.predict(X_test)
    chart_sample_count = min(40, len(y_test))
    test_indices = list(range(chart_sample_count))
    y_test_sample = y_test.iloc[:chart_sample_count].values
    y_pred_sample = rf_preds[:chart_sample_count]

    actual_vs_predicted = [
        {
            'sample_id': i + 1,
            'actual': round(float(y_test_sample[i]), 1),
            'predicted': round(float(y_pred_sample[i]), 1),
            'error': round(float(abs(y_test_sample[i] - y_pred_sample[i])), 1)
        }
        for i in range(chart_sample_count)
    ]

    # Save complete metrics report
    metrics_payload = {
        'models': metrics_results,
        'best_model': best_model_key,
        'best_model_name': models_def[best_model_key]['name'],
        'selection_reason': f"{models_def[best_model_key]['name']} achieved the highest prediction accuracy on the held-out test set with the lowest MAE ({metrics_results[best_model_key]['mae']} min) and RMSE ({metrics_results[best_model_key]['rmse']} min), balancing variance and capturing non-linear relationships.",
        'feature_importances': importance_list,
        'actual_vs_predicted': actual_vs_predicted,
        'test_size': len(y_test),
        'train_size': len(y_train)
    }

    with open(os.path.join(models_dir, 'metrics.json'), 'w', encoding='utf-8') as f:
        json.dump(metrics_payload, f, indent=2)

    print("\nTraining and Evaluation completed successfully!")
    print(f"Best Model Selected: {models_def[best_model_key]['name']}")
    print(f"Metrics saved to {os.path.join(models_dir, 'metrics.json')}")

if __name__ == '__main__':
    train_and_evaluate()
