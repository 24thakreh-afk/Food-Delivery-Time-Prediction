import os
import sys
import json
import sqlite3
import joblib
import pandas as pd
from datetime import datetime, timedelta
from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS

# Configure standard streams for international UTF-8 paths
if sys.stdout is not None:
    sys.stdout.reconfigure(encoding='utf-8', errors='replace')
if sys.stderr is not None:
    sys.stderr.reconfigure(encoding='utf-8', errors='replace')

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
MODELS_DIR = os.path.join(BASE_DIR, 'models')
DB_PATH = os.path.join(BASE_DIR, 'prediction_history.db')
DIST_DIR = os.path.join(os.path.dirname(BASE_DIR), 'frontend', 'dist')

app = Flask(__name__, static_folder=DIST_DIR if os.path.exists(DIST_DIR) else None)
CORS(app, resources={r"/api/*": {"origins": "*"}})

# ----------------- SQLite Database Setup ----------------- #
def init_db():
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS prediction_history (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp TEXT NOT NULL,
            restaurant_name TEXT,
            items_summary TEXT,
            distance_km REAL NOT NULL,
            weather TEXT NOT NULL,
            traffic_level TEXT NOT NULL,
            time_of_day TEXT NOT NULL,
            vehicle_type TEXT NOT NULL,
            preparation_time_min REAL NOT NULL,
            courier_experience_yrs REAL NOT NULL,
            pred_linear_regression REAL NOT NULL,
            pred_decision_tree REAL NOT NULL,
            pred_knn REAL NOT NULL,
            pred_random_forest REAL NOT NULL,
            best_model_used TEXT NOT NULL,
            best_predicted_time REAL NOT NULL,
            estimated_eta TEXT
        )
    ''')
    conn.commit()
    conn.close()

init_db()

# ----------------- Load Models and Metrics ----------------- #
MODEL_KEYS = ['linear_regression', 'decision_tree', 'knn', 'random_forest']
loaded_models = {}
metrics_cache = {}
summary_cache = {}

def load_ml_assets():
    global loaded_models, metrics_cache, summary_cache
    for key in MODEL_KEYS:
        model_path = os.path.join(MODELS_DIR, f"{key}.joblib")
        if os.path.exists(model_path):
            loaded_models[key] = joblib.load(model_path)
        else:
            print(f"Warning: Model file not found at {model_path}. Please run train_model.py first.")

    metrics_path = os.path.join(MODELS_DIR, 'metrics.json')
    if os.path.exists(metrics_path):
        with open(metrics_path, 'r', encoding='utf-8') as f:
            metrics_cache = json.load(f)

    summary_path = os.path.join(MODELS_DIR, 'dataset_summary.json')
    if os.path.exists(summary_path):
        with open(summary_path, 'r', encoding='utf-8') as f:
            summary_cache = json.load(f)

load_ml_assets()

# ----------------- API Endpoints ----------------- #

@app.route('/api/health', methods=['GET'])
def health_check():
    return jsonify({
        'status': 'healthy',
        'models_loaded': list(loaded_models.keys()),
        'database': 'ready'
    }), 200

@app.route('/api/models/metrics', methods=['GET'])
def get_metrics():
    if not metrics_cache:
        # attempt reload
        load_ml_assets()
    if not metrics_cache:
        return jsonify({'error': 'Model metrics not available. Please run train_model.py first.'}), 404
    return jsonify(metrics_cache), 200

@app.route('/api/analytics', methods=['GET'])
def get_analytics():
    if not summary_cache:
        load_ml_assets()
    return jsonify({
        'dataset_summary': summary_cache,
        'metrics': metrics_cache
    }), 200

@app.route('/api/predict', methods=['POST'])
def predict_delivery_time():
    try:
        data = request.get_json(silent=True)
        if not data:
            return jsonify({'error': 'Invalid or missing JSON in request body.'}), 400

        # Validate and extract features
        try:
            distance_km = float(data.get('distance_km', 0))
            if distance_km <= 0 or distance_km > 50:
                return jsonify({'error': 'Distance must be between 0.1 and 50 km.'}), 400

            prep_time = float(data.get('preparation_time_min', 15))
            if prep_time < 0 or prep_time > 120:
                return jsonify({'error': 'Preparation time must be between 0 and 120 minutes.'}), 400

            experience = float(data.get('courier_experience_yrs', 2))
            if experience < 0 or experience > 30:
                return jsonify({'error': 'Courier experience must be between 0 and 30 years.'}), 400

            weather = str(data.get('weather', 'Clear')).strip()
            traffic = str(data.get('traffic_level', 'Medium')).strip()
            time_of_day = str(data.get('time_of_day', 'Evening')).strip()
            vehicle = str(data.get('vehicle_type', 'Bike')).strip()

            restaurant_name = str(data.get('restaurant_name', 'Spice Garden Express')).strip()
            items_summary = str(data.get('items_summary', '2x Combo Meals')).strip()
            order_time_str = data.get('order_time', None)
        except (ValueError, TypeError) as val_err:
            return jsonify({'error': f"Invalid numeric input format: {str(val_err)}"}), 400

        # Create input DataFrame matching training feature columns
        input_dict = {
            'Distance_km': [distance_km],
            'Weather': [weather],
            'Traffic_Level': [traffic],
            'Time_of_Day': [time_of_day],
            'Vehicle_Type': [vehicle],
            'Preparation_Time_min': [prep_time],
            'Courier_Experience_yrs': [experience]
        }
        input_df = pd.DataFrame(input_dict)

        # Generate predictions from all four models
        predictions = {}
        for key in MODEL_KEYS:
            if key in loaded_models:
                pred_val = loaded_models[key].predict(input_df)[0]
                # Delivery time should logically be at least preparation time + positive transit time
                pred_val = max(round(float(pred_val), 1), round(prep_time + 3.0, 1))
                predictions[key] = pred_val
            else:
                return jsonify({'error': f"Model '{key}' is not loaded."}), 500

        # Best model selected dynamically based on test evaluation
        best_model_key = metrics_cache.get('best_model', 'linear_regression')
        best_model_name = metrics_cache.get('best_model_name', 'Linear Regression')
        best_prediction = predictions.get(best_model_key, predictions['linear_regression'])

        # Calculate estimated arrival time (ETA)
        now = datetime.now()
        if order_time_str:
            try:
                base_time = datetime.fromisoformat(order_time_str.replace('Z', '+00:00'))
            except Exception:
                base_time = now
        else:
            base_time = now

        eta_time = base_time + timedelta(minutes=float(best_prediction))
        estimated_eta = eta_time.strftime("%I:%M %p")

        # Save record to SQLite history
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        try:
            conn = sqlite3.connect(DB_PATH)
            cursor = conn.cursor()
            cursor.execute('''
                INSERT INTO prediction_history (
                    timestamp, restaurant_name, items_summary, distance_km, weather, traffic_level,
                    time_of_day, vehicle_type, preparation_time_min, courier_experience_yrs,
                    pred_linear_regression, pred_decision_tree, pred_knn, pred_random_forest,
                    best_model_used, best_predicted_time, estimated_eta
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', (
                timestamp, restaurant_name, items_summary, distance_km, weather, traffic,
                time_of_day, vehicle, prep_time, experience,
                predictions['linear_regression'], predictions['decision_tree'],
                predictions['knn'], predictions['random_forest'],
                best_model_name, best_prediction, estimated_eta
            ))
            conn.commit()
            record_id = cursor.lastrowid
            conn.close()
        except Exception as db_err:
            print(f"Warning: Failed to save to database: {db_err}")
            record_id = None

        response_payload = {
            'success': True,
            'record_id': record_id,
            'timestamp': timestamp,
            'input_features': {
                'distance_km': distance_km,
                'weather': weather,
                'traffic_level': traffic,
                'time_of_day': time_of_day,
                'vehicle_type': vehicle,
                'preparation_time_min': prep_time,
                'courier_experience_yrs': experience,
                'restaurant_name': restaurant_name,
                'items_summary': items_summary
            },
            'predictions': {
                'linear_regression': {
                    'name': 'Linear Regression',
                    'time_min': predictions['linear_regression'],
                    'r2': metrics_cache.get('models', {}).get('linear_regression', {}).get('r2', 0.82),
                    'mae': metrics_cache.get('models', {}).get('linear_regression', {}).get('mae', 6.06)
                },
                'decision_tree': {
                    'name': 'Decision Tree Regressor',
                    'time_min': predictions['decision_tree'],
                    'r2': metrics_cache.get('models', {}).get('decision_tree', {}).get('r2', 0.70),
                    'mae': metrics_cache.get('models', {}).get('decision_tree', {}).get('mae', 8.51)
                },
                'knn': {
                    'name': 'K-Nearest Neighbors (KNN)',
                    'time_min': predictions['knn'],
                    'r2': metrics_cache.get('models', {}).get('knn', {}).get('r2', 0.72),
                    'mae': metrics_cache.get('models', {}).get('knn', {}).get('mae', 8.30)
                },
                'random_forest': {
                    'name': 'Random Forest Regressor',
                    'time_min': predictions['random_forest'],
                    'r2': metrics_cache.get('models', {}).get('random_forest', {}).get('r2', 0.80),
                    'mae': metrics_cache.get('models', {}).get('random_forest', {}).get('mae', 6.77)
                }
            },
            'best_model': {
                'key': best_model_key,
                'name': best_model_name,
                'predicted_time_min': best_prediction
            },
            'estimated_eta': estimated_eta
        }

        return jsonify(response_payload), 200

    except Exception as ex:
        return jsonify({'error': f"Prediction error: {str(ex)}"}), 500

@app.route('/api/history', methods=['GET'])
def get_prediction_history():
    try:
        conn = sqlite3.connect(DB_PATH)
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        cursor.execute('SELECT * FROM prediction_history ORDER BY id DESC LIMIT 100')
        rows = cursor.fetchall()
        history = [dict(row) for row in rows]
        conn.close()
        return jsonify(history), 200
    except Exception as ex:
        return jsonify({'error': f"Failed to retrieve history: {str(ex)}"}), 500

@app.route('/api/history', methods=['DELETE'])
def clear_prediction_history():
    try:
        conn = sqlite3.connect(DB_PATH)
        cursor = conn.cursor()
        cursor.execute('DELETE FROM prediction_history')
        conn.commit()
        conn.close()
        return jsonify({'message': 'Prediction history cleared successfully.'}), 200
    except Exception as ex:
        return jsonify({'error': f"Failed to clear history: {str(ex)}"}), 500

@app.route('/api/history/<int:record_id>', methods=['DELETE'])
def delete_single_history(record_id):
    try:
        conn = sqlite3.connect(DB_PATH)
        cursor = conn.cursor()
        cursor.execute('DELETE FROM prediction_history WHERE id = ?', (record_id,))
        conn.commit()
        conn.close()
        return jsonify({'message': f"Record {record_id} deleted."}), 200
    except Exception as ex:
        return jsonify({'error': f"Failed to delete record: {str(ex)}"}), 500

# ----------------- Serve Frontend Dist (if built) ----------------- #
@app.route('/', defaults={'path': ''})
@app.route('/<path:path>')
def serve_frontend(path):
    if os.path.exists(DIST_DIR):
        if path != "" and os.path.exists(os.path.join(DIST_DIR, path)):
            return send_from_directory(DIST_DIR, path)
        return send_from_directory(DIST_DIR, 'index.html')
    return jsonify({
        'message': 'DeliverIQ Flask Backend API is active.',
        'frontend': 'Run Vite dev server at http://localhost:5173 or build frontend to serve statically.'
    }), 200

if __name__ == '__main__':
    print("Starting DeliverIQ Flask Backend on port 5000...")
    app.run(host='0.0.0.0', port=5000, debug=True)
